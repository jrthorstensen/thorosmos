#!/usr/bin/env python
"""osmosexposure.py -- Code for handing osmos header information, including
   a class to encapsulate the important stuff.
"""
import numpy as np
import thorsky.thorskyutil as tsu
import thorsky.thorskyclasses3 as tsc3
import astropy.coordinates as coo
import astropy.units as u
from astropy.wcs import WCS
from astropy.wcs.utils import pixel_to_skycoord
from astropy.time import Time
import astropy.io.fits as fits

import os   # operating system, not osmos!

# Some code for getting and setting info in osmos headers.
# Keys for surmising ROI from header parameters.

roidict = {(1088, 1024) : "1k", (4128, 1016) : "4x1k", (4128,4064) : "4k",
           (1080, 4064) : "1x4k", (2064, 508) : "4x1B"}

################################################################

# The inner and outer slits are almost 6 arcmin from the 
# telescope axis.  Header coords are those of the telescope axis.
# This bit of code infers the RA and dec of the target from the
# slit identification, the telscope coordinates, and the rotator 
# angle.

class rotatedobs :

   def __init__(self,telaxiscel,rotangle,time=Time('2020-01-01T00:00:00Z'),slit='inner'):

      # time is roughly now but need not be accurate to better than a couple years!  It's
      # here because the coordinate system of the instrument rotator is always in 
      # the present equinox, which after roughly 20 years has rotated just a little with 
      # respect to ICRS.

#      self.targcel = targcel   # defaults to None -- now a SkyCoord
#      This is vestigial - was used for the reverse transform, used only for testing.

      self.telaxiscel = telaxiscel # a SkyCoord
      self.rot = coo.Angle(rotangle,unit='deg')  # convert to an Angle

      # self.telaxiscel.selfprecess(2019.)
      self.currentfr = tsu.currentFK5frame(time)  # rotator frame is always in the current epoch.
      self.telaxiscel.transform_to(self.currentfr)
      self.tanplane = self.maketanplane(self.telaxiscel)

      self.implied_obj_cel = None
      self.implied_obj_miss = None
      self.implied_obj_xieta = None   # [xi, eta] of implied position around true 
      self.slit = slit  # Now just characters.
                     # inner is at x = -342, y = 0; outer at x = +345, so 
                     # it's close enough to use an integer.

   def maketanplane(self, centercoord) :  # makes a tangent plane WCS around a SkyPosition
        # this follows procedures demonstrated in Shupe et al.'s little paper on the 
        # Palomar Transient Factory astrometry pipeline,
        # PROC. OF THE 17th PYTHON IN SCIENCE CONF. (SCIPY 2018)
        # -- basically, the xi/eta stuff is built into that package though it's a bit
        # obscure.  The idea is to create a WCS out of 'tin hair'. 
    
        w = WCS(naxis=2)
        w.wcs.crpix = [0.0,0.0]   # origin of the tangent plane in 'pixel' coords
        w.wcs.cdelt = np.array([1./3600.,1./3600.])  # coordinate units are 1 arcsecond.
        w.wcs.crval = [centercoord.ra.deg,centercoord.dec.deg]
        w.wcs.ctype = ["RA---TAN","DEC--TAN"]
        return w
    
   def guess_obj_from_tel(self) :

      # given telescope coords plus rotator, guess object coords

      # X and Y are in a system aligned with the rotator with origin on the
      # telescope axis (ideally).

      if self.slit.upper().find('INNER') > 0:
          X = -342.  # inner
      elif self.slit.upper().find('OUTER') > 0:
          X = 345.   # outer
      else :
          X = 0.     # center, in which case this procedure isn't needed.
      Y = 0.         # Object is set somewhere near the middle in Y.

      # rotate this into tangent plane system
      # no need to convert since self.rot is an Angle
      
      Xprime = np.cos(self.rot) * X + np.sin(self.rot) * Y   
      Yprime = -1. * np.sin(self.rot) * X + np.cos(self.rot) * Y

      # and transform to a SkyCoord

      self.implied_obj_cel = pixel_to_skycoord(Xprime,Yprime,self.tanplane)
      self.implied_obj_cel.transform_to("icrs")

###################

# a class for encapsulating the most important information about a 
# single osmos exposure.

class osexposure :
   # information on a single exposure.
   # The instantiation does almost nothing.  This is an odd design.
   def __init__(self, fname) :
      print 'fname = ',fname
      self.fname = fname
      self.localfname = os.path.split(fname)[-1]
      try :
         self.parentdir = os.path.split(fname)[-2]
      except :
         self.parentdir = None
      self.reducedname = None  # with the standard prefix (usually two letters)
      self.num = None          # sequence number (int)
      self.telescope_cel = None # telescope axis coords (from header)
      self.implied_obj_cel = None           # inferred coordinates of target
      self.rotangle = None
      self.title = None
      self.imagetyp = None
      self.isfocus = False
      self.exptime = None
      self.jd = None
      self.filter1 = None 
      self.filter1id = None
      self.filter2 = None 
      self.filter2id = None
      self.disperser = None
      self.slit = None 
      self.naxis1 = None
      self.naxis2 = None
      self.roi = None
      self.mirror = None 
      self.lamps = None
      self.adjacent_comps = None
      self.setup = None
      self.obs = None

   def setinfo(self, writeout = True) :
      """opens the file, reads and fills in the instance variables, and does 
         some useful time-and-the-sky stuff too."""

      # the ROIdict is keyed to original image sizes, so grab those quickly 
      # this was a somewhat unexpected bug that might better be fixed by
      # including trimmed image sizes in the roidict keys, but I don't have
      # trimmed images of all sizes to use as examples so this is safer.

      hdu = fits.open(self.fname)
      hdr = hdu[0].header
      self.naxis1 = int(hdr['naxis1'])
      self.naxis2 = int(hdr['naxis2'])
      self.roi = roidict[(self.naxis1, self.naxis2)]
      hdu.close()
      
      if self.reducedname.find('.fits') < 0 : infname = self.reducedname + ".fits"
      else : infname = self.reducedname
      hdu = fits.open(infname,mode='update')  # we're gonna write to it!
      hdr = hdu[0].header
      # extract a file number -- won't work unless there are no other numbers in 
      # name.
      numstr = ''
      for c in self.fname : 
          if c.isdigit() : numstr = numstr + c
      self.num = int(numstr)
      rastr = hdr['ra']
      decstr = hdr['dec']
      eqnx = float(hdr['equinox'])
      if eqnx == 2000.:
         self.telescope_cel = coo.SkyCoord(rastr,decstr,unit=(u.hourangle,u.deg),frame='icrs')
      else :
         self.telescope_cel = coo.SkyCoord(rastr,decstr,unit=(u.hourangle,u.deg),
             frame=coo.FK5(equinox = eqnx))
      
      # find and set target coordinates given telescope pointing.

      self.rotangle = float(hdr['rotangle'])
      self.slit = hdr['slitid']

      rot = rotatedobs(self.telescope_cel,self.rotangle,slit=self.slit)
      rot.guess_obj_from_tel()
      self.implied_obj_cel = rot.implied_obj_cel  

      self.title = hdr['object']
      self.imagetyp = hdr['imagetyp']
      self.exptime = float(hdr['exptime'])
      self.jd = float(hdr['jd'])   # start of exposure, geoconentric UT based.
      self.jdmid = self.jd + self.exptime / (2. * 86400.)
      self.filter1 = int(hdr['filter1'])
      self.filter1id = hdr['filtid1'] 
      self.filter2 = int(hdr['filter2'])
      self.filter2id = hdr['filtid2']
      self.disperser = hdr['dispid'].strip()  
      self.disperser = self.disperser.replace(' ','_')
      self.slit = hdr['slitid'].strip()
      self.slit = self.slit.replace(' ',"_")
      self.naxis1 = int(hdr['naxis1'])
      self.naxis2 = int(hdr['naxis2'])
      self.mirror = hdr['mirror'].strip()
      self.lamps = hdr['lamps'].strip()

      self.setup = self.slit + "_" + self.disperser + self.roi
     
      if self.title.upper().find('FOCUS') > -1 :
          self.isfocus = True

      # compute and fill in other information in header.

      self.obs = tsc3.Observation(celest = self.implied_obj_cel, t = self.jdmid, site='mdm')
      self.obs.computesky()
      self.obs.computesunmoon()
      self.obs.computequickbary()

      hdr['telra'] = self.telescope_cel.ra.to_string(unit=u.hourangle,sep=':',precision=2,pad=True)
      hdr['teldec'] = self.telescope_cel.dec.to_string(sep=':',precision=0,pad=True)
      hdr['objra'] = self.implied_obj_cel.ra.to_string(unit=u.hourangle,sep=':',precision=2,pad=True)
      hdr['objdec'] = self.implied_obj_cel.dec.to_string(sep=':',precision=0,pad=True)
      hdr['jdmid'] = self.jdmid
      hdr['hjd'] = self.obs.tbary.jd
      hdr['bjd'] = self.obs.tbary.jd
      hdr['hcv'] = self.obs.baryvcorr.value   # actually barycentric; names are legacy
      hdr['vhelio'] = self.obs.baryvcorr.value
      hdr['twilight'] = self.obs.twi     # estimated zenith twilight.
      hdr['lunsky'] = self.obs.lunsky    # estimated lunar sky brightness

      if writeout : 
          hdu.flush()
          hdu.close()
      
   def printall(self) :  # mostly for diagnostics.
      print "filename: ", self.fname
      print "tel coords:",self.telescope_cel.ra.to_string(unit=u.hourangle,sep=':'),' ', \
                          self.telescope_cel.dec.to_string(unit=u.deg,sep=':')
      print "coords:",self.implied_obj_cel.ra.to_string(unit=u.hourangle,sep=':'),' ', \
                          self.implied_obj_cel.dec.to_string(unit=u.deg,sep=':')
      print "rotangle ", self.rotangle
      print "object:", self.title
      print "type  :",  self.imagetyp 
      print "exp, jd, ",self.exptime,self.jd
      print "filter1 ", self.filter1, self.filter1id 
      print "filter2 ", self.filter2, self.filter2id
      print "disperer", self.disperser
      print "slit : ", self.slit
      print "format : ", self.naxis1, " x ",self.naxis2
      print "roi : ",self.roi
      print "mirror, lamps: ", self.mirror, self.lamps
      print "setup:", self.setup

   def set_reduced_name(self, prefix) :
      root = self.localfname.replace('.fits','')
      # print root
      x = root.split('.')
      # print x, x[-1]
      self.num = int(x[-1])   # this means originals must be e.g. b.0001.fits
      self.reducedname = prefix + "%04d" % (self.num)
      self.reducedname = self.reducedname.strip()

   def set_target_cel(self) :  # assumes info has been loaded.
      ro = rotatedobs(self.telescope_cel,self.rotangle)
      ro.slit = 0
      try :
           if(self.slit[1].find('nner') > -1) : 
                 ro.slit = 1
           elif(self.slit[1].find('uter') > -1) :
                 ro.slit = -1 
      except :
           pass 

      ro.guess_obj_from_tel()
      self.cel = deepcopy(ro.implied_obj_cel)  

      # this now automatically hands back a SkyCoord in ICRS.

if __name__ == "__main__" : 
     
    ose = osexposure('../osmosraw/190701/b.0340.fits')
    ose.set_reduced_name('x')  # argument is prefix
    os.system("cp %s %s" % (ose.fname,ose.reducedname + ".fits"))
    ose.setinfo() 
    ose.printall()
