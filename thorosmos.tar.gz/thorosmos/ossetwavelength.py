#! /usr/bin/env python
"""ossetwavelength.py  --
    applies wavelength solutions to spectra in an object root
    list.  The list of images to operate on is of the form 

            obj_[setup string]

    These will ordinarily have been written the last time
    osmosspecreduct.py was run, so should contain only new
    spectra.  If this isn't the case, you'll have to create the
    appropriate list of filename roots, e.g. kf0123 
  
    The wavelength solutions are single well-fitted solutions
    that are specified in the "osmospecred.config" file.

    Before running this you need to derive the solutions (if you
    haven't already), copy the comp spectrum to the directory
    you're working in, AND copy the "idxxxxxx" file corresponsding
    to the comp spectrum ("xxxxxx" or whatever) into the 
    "database" directory immediately below this one.  And, 
    of course, enter them in the osmospecred.config file.

    The first versions of this task simply measured the wavelength
    of 5577 in the sky spectrum (band 3 of the multispec
    format, or 2 if zero-indexed) and shifted the spectrum
    to make that zero.  This proved inadequate, since the 
    OSMOS spectrum not only shifts, but stretches by as
    much as a few parts per thousand.  

    This version is more elaborate, optionally using a
    set of N/S features from Osterbrock's paper to derive
    a stretch, and manipulating the wavelength solution 
    directly.  

    I plan to implement the possibility of deriving the shift
    and stretch from an adjacent short comp exposure.

"""
import sys
from pyraf import iraf
import gc 

from iraf import images,imcopy,imdelete,hedit # imrename
from iraf import noao,imred,specred,refspectra,dispcor

import astropy.io.fits as fits
import astropy.units as u

from astropy.coordinates import SkyCoord
import thorsky.thorskyutil as tsu
import thorsky.thorskyclasses3 as tsc3

import numpy as np
import matplotlib.pyplot as plt

import convel as cv

import argparse

parser = argparse.ArgumentParser(description="Wavelength-calibrate extracted OSMOS specs.")
parser.add_argument("--review",help="review each result by hand.",
    action="store_true")

args = parser.parse_args()

# '--review' defaults to False.

# print "args.review = ",args.review
# sys.exit()


import os

def get_config() : 
    try : 
        inf = open("osmosspecred.config","r") 
    except :
        print "You need a file called 'osmosspecred.config'."
        print "This must have these defined (with examples here):"
        print "PREFIX | kf    # two-letter prefix for reduced"
        print "RAWPARENT | /home/thorsten/iraf/dec18/osmosraw "
        print ".... exiting."
        sys.exit()

    prefix = None   #initialize to allow leaving them out
    rawdir = None
    setups_to_omit = []
    noflatfield = []   # setups which you won't bother to flatfield
    displine = {}   # dispersion line for finding spec (usually the col
                     # containing H-alpha, keyed to spectral setup.
    wavecal = {}    # name of wavecal spectrum, keyed to setup.  These must
                    # already have had ident run and have excellent solutions.
    w1 =      {}    # wavelength binning parameters, also keyed to setup. 
    dw =      {}
    nw =      {}
    lowpixblue = {} # direction for night-sky shifting of spec.

    for l in inf : 
        if l[0] != '#' :
            x = l.split('|')
            if x[0].upper().find('PREFIX') > -1 : 
                if x[1].find("#") :
                    y = x[1].split('#')
                    prefix = y[0].strip()
                else : 
                    prefix = x[1].strip()
            if x[0].upper().find('RAWPARENT') > -1 :
                if x[1].find('#') :
                    y = x[1].split('#')
                    rawdir = y[0].strip()
                else : 
                    rawdir = x[1].strip()

            if x[0].upper().find('OMITSETUP') > -1 :
                if x[1].find('#') :
                    y = x[1].split('#')
                    setups_to_omit.append(y[0].strip())
                else : 
                    setups_to_omit.append(x[1].strip())

            if x[0].upper().find('NOFLATFIELD') > -1 :
                if x[1].find('#') :
                    y = x[1].split('#')
                    noflatfield.append(y[0].strip())
                else : 
                    noflatfield.append(x[1].strip())

            if x[0].upper().find('DISPLINE') > -1 :
                displine[x[1].strip()] = int(x[2])

            if x[0].upper().find('WAVECAL') > -1 :                
                wavecal[x[1].strip()] = x[2].strip()

            if x[0].upper().find('W1') > -1 :                
                w1[x[1].strip()] = float(x[2])

            if x[0].upper().find('DW') > -1 :                
                dw[x[1].strip()] = float(x[2])

            if x[0].upper().find('NW') > -1 :                
                nw[x[1].strip()] = int(x[2])

            if x[0].upper().find('LOWPIXBLUE') > -1 :  # 1 = low pixels are blue end
                lowpixblue[x[1].strip()] = int(x[2])           # -1 = low pixels are red end

    return (prefix, rawdir, setups_to_omit, noflatfield, 
             displine, wavecal, w1, dw, nw, lowpixblue)

prefix, rawdir, setups_to_omit, noflatfield, displine, wavecal, \
   w1, dw, nw, lowpixblue = get_config()

lightsp = 299792.458   # If you don't recognize this, go get another job.
nswav = 5577.339       # precise wavelength of the [OI] airglow line

w2 = "INDEF"  # always want a fixed number of pixels in the output spectrum.

#########################################################################

# Material copied from prototype function 'adjust_to_ns.py'

# This routine copies the master comp's database/id file -- where
# IRAF stores wavelength solutions -- but in so doing it tweaks two
# of the parameters that shift and scale the legendre poly solution.
# Tests give hope that this can remove both a zeropoint shift and 
# a linear 'stretch'.

# this does double-duty as a thing to read the central wavelength
# and range from the coefficients in an existing refcomp; just 
# specify fakenameroot = None to get those handed back.

def tweak_dispersion(refcomp, ctrshift = 0., scalefac = 1.,
       fakenameroot = "fakedbluecomp") :

    if fakenameroot == None : write_output = False
    else : write_output = True

    # copy the dispersion solution and tweak a couple of 
    # parameters.

    refdispfile = open("database/id" + refcomp,"r")
    if write_output: 
        outf = open("database/id%s" % (fakenameroot),"w")
        print "opened database/id%s" % (fakenameroot)
    linenum = 0
    coefficients_found = False 
    coeffs = []  # hand them all back in case more elaborate measures needed
    for l in refdispfile : 
        # print l
        # line numbers are easy way to keep track of header
        # not sure it's necessary to fake this
        linenum = linenum + 1
        if linenum == 2 and write_output: 
            outf.write("begin\tidentify\t%s - Ap 1\n" % (fakenameroot))
        elif linenum == 3 and write_output:
            outf.write("\t  id  %s  TAG \n" % (fakenameroot))
        elif linenum == 4 and write_output: 
            outf.write("\t  %s - Ap 1\n" % (fakenameroot));
        elif not coefficients_found : 
            if write_output : outf.write(l)
        else :  # we're in the coefficients, which is the business end
            coeff_num = coeff_num + 1
            # print "coeff_num = ", coeff_num, "l = ", l,"len(l) = ",len(l)
            # blank lines cause problems, so append conditionally
            if len(l) > 1 and l[0] != '#': coeffs.append(float(l.strip()))
            if coeff_num == 5 :
                dispcenter = float(l.strip())
                print "dispcenter ",dispcenter
                if write_output : outf.write("\t\t%17f\n" % (dispcenter + ctrshift))   
                print "wrote dispcenter + ctrshift = ",dispcenter + ctrshift
            elif coeff_num == 6 :
                window = float(l.strip())
                print "window ",window
                if write_output : outf.write("\t\t%17f\n" % (window * scalefac))    # also a test
                print "write window * scalefac ",window * scalefac
            else : 
                if write_output : outf.write(l)
            if l[0] == "#" : # there is a line at the top of each solution with a timestamp 
                # --- if encountered here, it means that ...
                # oops, there's another solution appended to the id file.  Scratch and start over.
                coefficients_found = False
                coeffs = []
                coeff_num = 0
        if l.find('coefficients') > -1 :
            coefficients_found = True
            coeff_num = 0

    refdispfile.close() 
    if write_output : outf.close() 
    if not write_output : return dispcenter, window, coeffs

#####################################################################

def robust_straightline(xtofit, ytofit, errs, maxresid = 0.3) :   

    # Fits a straight line, and iterates if outliers bigger than 
    # maxresid. Used for non-interactive fit of the delta-wavelengths 
    # of the night sky spectrum.

    maxerr = 1e6  # to start the loop.

    # We'll be deleting points from the array, so make copies to avoid
    # corrupting the originals.

    xarr = xtofit[:]
    yarr = ytofit[:]   
    wgtarr = []
    for e in errs : 
       # weights, with a very rough normalization factor thrown in.
       wgtarr.append(100. / (e * e))
    # print xarr,yarr,wgtarr
    xdeleted = []
    ydeleted = []

    iteration = 0
    while(maxerr > 0.5 and iteration < 4) :  # hard number ok since we have a particular setup
        iteration = iteration + 1
        residsq = []
#        print "iteration %d len(xarr) = %d" % (iter,len(xarr))
        if len(xarr) > 2 :  # stop if you've thrown too much away
            fitcoefs = np.polyfit(xarr, yarr,1,w = wgtarr) 
            maxerr = 0.
            for x in xarr :  
                ind = xarr.index(x)
                y = yarr[ind]
                resid = abs(y - np.polyval(fitcoefs,x))
                residsq.append(resid * resid)
#                print "ind %d x %f y %f resid %f" % (ind,x,y,resid)
                if resid > maxresid and len(xarr) > 3 :
                    xdeleted.append(xarr[ind])
                    ydeleted.append(yarr[ind])
                    del xarr[ind]
                    del yarr[ind]
                    del wgtarr[ind]
                if resid > maxerr : 
                    maxerr = resid

            residsqarr = np.array(residsq) 
            meansq = np.sum(residsqarr) / residsqarr.shape[0]
            rms = np.sqrt(meansq)
#            print("iteration %d: %d points, rms = %f" % (iteration, len(residsq), rms))
           
   
    # return number of points used, which can be used as a quality screen.

    return (fitcoefs, len(xarr), xdeleted, ydeleted, rms)

################################################

# this "onpress" is for passing key-based commands back from a
# matplotlib plot.  For reasons I don't completely understand this 
# has to be mutable object -- I tried using a list, which should
# mutable, but it didn't work right away.  The example cited below
# uses a dictionary, which apparently does work.

# I have not tested this business of rejecting N/S fits very extensively.
# In practice, it's generally better than nothing in any case.

acceptfit = {}  # this is mutable ... 

# See: 
# https://stackoverflow.com/questions/15032638/how-to-return-a-value-from-button-press-event-matplotlib

# 'onpress' is later linked to key press events.

def onpress(event) :  # for use in reviewing solutions.
    # print "event.key = ",event.key
    if event.key.upper() == 'Q' :
        plt.close() 
    if event.key.upper() == 'X' or event.key.upper() == 'D' or event.key.upper() == 'R' :
        # print "event.key = ",event.key
        acceptfit['key'] = event.key
        # print "acceptfit = ",acceptfit
    
################################################

# NIGHT-SKY AND COMPARISON CALIBRATION LINES

# I'm setting them as a dictionary keyed by the slit so as to
# be able to use the same procedure in different setups.

# More properly these should include the disperser information,
# but the inner slit is used almost always with the blue grism, 
# the outer with the red, and the center not much.

# The night-sky wavelengths are from Osterbrock et al's 1996
# PASP paper on the night-sky spectrum from the Keck high resolution 
# spectrograph.

# The linelist for the "center" slit is a guess -- I haven't taken 
# any data in the 
# center slit for some time.  I think it's usually used with the red
# grism in which case the 'outer' set - designed for red grism + outer --
# may be a better starting point.  The list here assumes the blue grism
# plus center slit, which covers only one strong N/S feature, 5577.

nswavdict = { 'inner' : [5577.338,5915.301,5932.862,5953.420,5977.1,
                6170.638,6257.961,6287.434,6300.304,
                6498.729, 6533.044, 6577.2],
              'center' : [5577.338],  
              'outer' : [5577.338, 6300.304, 6863.96, 7276.41, 7340.89,
                7524.1, 7794.11, 7964.65, 8344.602, 8399.17, 8430.17, 8827.096]}

# Here are wavelengths from HgNe for 'inner' with blue grism, 
# 'outer' with red grism, and 'center' with blue grism -- which should
# probably be the red grism since center slit is seldom used with the 
# blue grism.

# 2019 Sept - dropped 6717.048 from 'inner'.
# 2019 Dec - dropped 4047, 4358

hgnedict = { 'inner' : [5460.74, 5769.598, 5790.659,
               5852.488, 5944.834, 5975.535, 6029.997, 6074.338,
               6096.163, 6143.063, 6217.281, 6266.495, 6334.428,
               6402.246, 6506.528, 6532.882, 6598.953 , 6678.277],
               'center' : [4046.530, 4358.343, 5460.74, 5769.598, 5790.659,
               5852.488], 
               'outer' : [5460.74, 5769.598, 5790.659,
               5852.488, 5944.834, 5975.535, 6029.997, 6074.338,
               6096.163, 6143.063, 6217.281, 6266.495, 6334.428,
               6402.246, 6506.528, 6532.882, 6598.953 , 6678.277,
               6717.048, 6929.468, 7173.939, 7245.1670, 
               7438.8990, 7488.871, 8082.458, 8136.405, 8300.326, 
               8377.608, 8495.360, 8591.258, 8634.647, 8654.383, 
               8919.501, 8418.427, 8377.608]}
 
#hgnedict = { 'inner' : [4358.343, 5460.74, 5769.598, 5790.659,
#               5852.488, 5944.834, 5975.535, 6029.997, 6074.338,
#               6096.163, 6143.063, 6217.281, 6266.495, 6334.428,
#               6402.246, 6506.528, 6532.882, 6598.953 , 6678.277],
#               'center' : [4046.530, 4358.343, 5460.74, 5769.598, 5790.659,
#               5852.488], 
#               'outer' : [5460.74, 5769.598, 5790.659,
#               5852.488, 5944.834, 5975.535, 6029.997, 6074.338,
#               6096.163, 6143.063, 6217.281, 6266.495, 6334.428,
#               6402.246, 6506.528, 6532.882, 6598.953 , 6678.277,
#               6717.048, 6929.468, 7173.939, 7245.1670, 
#               7438.8990, 7488.871, 8082.458, 8136.405, 8300.326, 
#               8377.608, 8495.360, 8591.258, 8634.647, 8654.383, 
#               8919.501, 8418.427, 8377.608]}
#               # 8853.867, 8919.501, 8418.427, 8377.608]}

#################################################################

# Back to main Main MAIN task.

setupkeys = wavecal.keys()   # these are e.g. Blue_1.2_inner4x1k  or whatever

# print setupkeys
# print setups_to_omit

for s in setups_to_omit : 
    if s in setupkeys :
        setupkeys.remove(s)
 
# Do each setup in turn.

for k in setupkeys : 

    print "Starting wavelength calibs for %s." % (k)

    try :
        inf = open("obj_%s" % k,"r") 
    except :
        print "No list of images to operate on for setup %s" % (k)
        inf = None 

    if inf != None : 

       # see if there are adjacent comparison spectra to override 
       # adjustments based on the night sky spectrum.

       adjcompdir = {}  # adjacent comparisons.
       interpolatdir = {} # interpolation factors if needed

       try : 
           complist = open("adjacent_comps_%s" % k,"r")
       except : 
           complist = None
    
       if complist != None : 
           for l in complist : 
               x = l.split()
               adjcompdir[x[0]] = x[1:]  

#           for k in adjcompdir.keys() : 
#               print k 
#               print adjcompdir[k]

       calibspec = wavecal[k]  # this is the fiducial calibration spectrum, 
                   # which needs to have a wavelength solution in the 
                   # ./database directory.
       thisw1 = w1[k]
       thisdw = dw[k]
       thisnw = nw[k]

       # Get the central wavelength, spectrum span from the 
       # fiducial calibration spectrum (and the rest of the coeffs also).  
       # Giving 'None' for fakenameroot
       # makes this just read and report without tweaking anything.
       
       (referencewav, referencespan, referencecoeffs) = \
            tweak_dispersion(calibspec, fakenameroot = None) 

       print "The fiducial calibration derived from %s has:" % (calibspec)
       print "cen, win", referencewav, referencespan
       # print "referencecoeffs = ",referencecoeffs
       
       # open some outfiles for redos and diagnostics
       rejectedlist = open("rejected_%s" % k,"w")
       diagnosticlist = open("ns_fit_diagn_%s" % k,"w")

       if k.lower().find('inner') > -1 :
           nswavelengths = nswavdict['inner']
           hgnewavelengths = hgnedict['inner']
           fakenameroot = "fakedbluecomp"
       elif k.lower().find('outer') > -1  : 
           nswavelengths = nswavdict['outer']
           hgnewavelengths = hgnedict['outer']
           fakenameroot = "fakedredcomp"
       else : 
           nswavelengths = nswavdict['center']
           hgnewavelengths = hgnedict['center']
           fakenameroot = "fakedcentercomp"

       imroots = []
       for l in inf : 
           inname = l.strip()
           inname = inname.replace(".fits","")
           inname = inname.replace(".ms","")
           imroots.append(inname)
        
       print "read %d image names." % (len(imroots))
    
       for outputimage in imroots :  # root name, without a .ms in it.

           dispname = "d%s.fits" % (outputimage)
           comstr = "/bin/rm %s" % (dispname) 
           os.system(comstr)
           os.system("/bin/rm tempspec.fits")  
           os.system("/bin/rm tempspec2.fits")   
 
           # Let's get some time and the sky info, and also compute and set
           # heliocentric corrections.  The helio stuff is computed earlier in the 
           # most recent osspecreduct, but no harm in doing it again here on 
           # older partially-processed data.

           hdu = fits.open(outputimage + ".ms.fits",mode = 'update')
           hdr = hdu[0].header

           try : # more recent pre-processing versions set exact object coords
               rastr =  hdr['objra']   # These are colon-separated strings
               decstr = hdr['objdec']
               equinox = hdr['objeq']
           except :
               # print "using default header ra/dec/eq"
               # the optical axis coords are plenty close enough here.
               rastr =  hdr['ra']
               decstr = hdr['dec']
               equinox = hdr['equinox']
           
           # create an astropy SkyCoord, and force coords to ICRS.
           
           if equinox == 2000. :
              cel = SkyCoord(rastr,decstr,unit=(u.hourangle,u.deg))  # defaults to ICRS
           else :
              eqtime = Time(equinox,format='jyear')
              telframe = tsu.currentFK5frame(eqtime)
              cel = SkyCoord(rastr,decstr,unit=(u.hourangle,u.deg),frame = telframe)
              cel.transform_to('icrs')
           
           jdmid = hdr['jd'] + hdr['exptime'] / (2. * 86400.)

           # quickbary function added 2019 July is a lot faster than the 
           # one supplied by astropy, and far more accurate than needed for
           # osmos data (conservatively +- 10 m/s and +- 0.1 sec).

           obs = tsc3.Observation(celest = cel, t = jdmid, site = 'mdm')
           obs.computesky()
           obs.computesunmoon()
           obs.computequickbary()

           vcorr = obs.baryvcorr.to(u.km/u.s).value
           hdr['HCV'] = vcorr               # different programs want different keywords
           hdr['VHELIO'] = vcorr
           hdr['HJD'] = obs.tbary.jd       
           hdr['BJD'] = obs.tbary.jd       

           objname = hdr['object']  # for later plot labeling
           exptime = hdr['exptime']  
           # also grab a couple of parameters for exploring what causes the
           # wavelength calibration to vary so much.
           benchtemperature = hdr['obtemp']   
           camfoc = hdr['camfoc']
           
           hdu.flush()  # updates the header of the .ms file.
           hdu.close()

           imcopy(outputimage + ".ms","tempspec2")   # make a copy with no wave cal info 
                                                     # so you can install pristinely later

           # We now get a giant branching based on whether we tweak the wavelengths 
           # using the night-sky band in the spectrum, or using an adjacent comparison.

           if adjcompdir.has_key(outputimage) : # Use adjacent comps if avail.

               comps = adjcompdir[outputimage] # list of adjacent comps, either 1 or 2 of them.

               thiscomp = 0  # index to keep track of which comp

               # We want to be able to interpolate in time between comps.  This 
               # means keeping information about up to two fits, which we'll do 
               # in tiny lists of two elements; the lists are mostly named the 
               # same as the things that go into them, with an 's' appended to 
               # indicate plural.

               compjdlist = []
               shift_at_midwavs = []
               scalefacs = []
    
               for c in comps :
                   compname = c + ".0001.fits"   # they're all onedspec

                   # We dispcor this using the reference spec without linearizing,
                   # then measure the lines in it and derive the shift and stretch from them.

                   hduc = fits.open(compname,mode='update')
                   hdrc = hduc[0].header
                    
                   compjdlist.append(hdrc['jd'])  # a tiny list of up to two elements

                   # if this comp is used for more than one spec we'll load the headers,
                   # measure the lines, etc., several times, but the execution time should
                   # not be much of an issue.

                   # set header keyword and ... 

                   hdrc['refspec1'] = calibspec   
                   hduc.flush()  # needs refspec1 in the actual file.
                   hduc.close()  # Needs to have the fully updated file on disk for the next step

                   # ... write the fiducial coefficients into the comp's header, without 
                   # rebinning the comp spectrum.

                   dispcor(compname, compname, linearize="no", database = "database",
                         w1 = "INDEF", w2 = "INDEF", dw = "INDEF", nw = "INDEF", 
                         confirm = "no", ignoreaps = "yes", listonly = "no", verbose = "yes")
   
                   # Now that the comp has a wavelength solution applied, measure the 
                   # apparent wavelengths. 
 
                   deltawavs = {}   # dictionary by rest wavelength
                   waverrs = {}        # rough estimated error by wavelength

                   for n in hgnewavelengths : 
                       (vel,err) = cv.specvel(compname,0,n,half_wid = 8., linwid=5.,
                          search_wid=20., rootsearch = True, do_error = False, raw_error = True, 
                          helio_correct = False) # , debug=True)
                   #    print("wav %f : vel %f, err %f" % (n,vel,err))
    
                       # convert the velocity to a wavelength shift.
    
                       delta = (vel / lightsp) * n
                       waverr = err * n / lightsp

                       if abs(err) < 15. and abs(waverr) > 0. :  # also avoid zeros (returned when 
                                                                 # something goes wrong in specvel).
                           deltawavs[n] = delta
                           waverrs[n] = waverr
                   
                   # stack the results in lists ordered by wavelength.
                   # This may be overly complicated by it doesn't matter much.
    
                   restwavs = deltawavs.keys()
                   restwavs.sort()
                   shiftarr = []
                   error_arr = []
                   
                   for r in restwavs :
                       shiftarr.append(deltawavs[r])
                       error_arr.append(waverrs[r])

                   # optionally view result.
    
                   if args.review :
    
                      fig = plt.figure()
                      cid = fig.canvas.mpl_connect('key_press_event',onpress)
    
                      plt.plot(restwavs, shiftarr,'bo')
                      plt.errorbar(restwavs,shiftarr,error_arr,fmt='o')
    
                   shiftarr_uncorr = shiftarr
                   restwavs_orig = restwavs
    
                   # Fit a robust straight line, iteratively excluding residuals too large.
    
                   if len(restwavs) > 2 : 
                       # print "restwavs ",restwavs
                       # print "shiftarr ",shiftarr
                       # print "error_arr",error_arr
                       (shiftmodel, nkept, xdeleted, ydeleted,rms) = robust_straightline(restwavs,
                                  shiftarr,error_arr,maxresid=0.5)  
    
                       if args.review : 

                           # overstrike deleted points
                           plt.plot(xdeleted,ydeleted,'x',markersize=15)
     
                           # plot the fitted straight line
                           y1 = np.polyval(shiftmodel, restwavs[0])
                           y2 = np.polyval(shiftmodel, restwavs[-1])
                           plt.plot([restwavs[0],restwavs[-1]],[y1,y2],'-')
                           plt.title("Comp %s" % (compname))
                           plt.show()
        
                       # print "shiftmodel:",  shiftmodel

                       print "npts kept",nkept
    
                       # shiftmodel[1] is the y-intercept at wavelength zero and 
                       # shiftmodel[0] is the slope.  Find the shift at the middle of 
                       # the spectrum from this, and also the scale factor to apply to 
                       # the results.

                       shift_at_midwav = shiftmodel[0] * referencewav + shiftmodel[1]
                       scalefac = 1.00 - shiftmodel[0]
                       print "shift at mid:", shift_at_midwav," scalefac: ",scalefac
                       # keep lists in case we're going to interpolate.
                       if nkept > 5 and rms < 0.5 : 
                           shift_at_midwavs.append(shift_at_midwav)
                           scalefacs.append(scalefac) 
                           correction_text = "comp %s: shift %6.2f A, scale %8.6f" % (compname,shift_at_midwav,
                                            scalefac)
        
                   else :
                       nkept = len(restwavs)
                       print "Too few line centers survive for a fit."

                   if nkept < 5 or rms > 0.5 :  # fit failed
                       print "FIT FAILED, will not correct." 
                       shift_at_midwav = 0.
                       scalefac = 1.00
                       correction_text = "Adjacent comp fit failed."
               
                   thiscomp = thiscomp + 1   

               # If there are two comps, interpolate the solutions.

               if len(shift_at_midwavs) > 1 : 
                   # make this work even if not time-ordered properly
                   # replaced compjds with compjdlist -- apparently an undriven bug
                   delta_t = abs(compjdlist[1] - compjdlist[0])
                   wgt0 = abs((compjdlist[1] - jdmid)) / delta_t
                   wgt1 = 1. - wgt0
                   shift_at_midwav = shift_at_midwavs[0] * wgt0 + shift_at_midwavs[1] * wgt1
                   scalefac = scalefacs[0] * wgt0 + scalefacs[1] * wgt1
                   correction_text = "Interpolated comps, shift %6.2f A, scale %8.6f" % (shift_at_midwav,
                         scalefac)

               # We FINALLY have derived and possibly interpolated the scale factors and shifts.
               # Now use it to tweak the wavelenghts in the program spec

                   # First, write a faked calibration in the database:
                        
               tweak_dispersion(calibspec,ctrshift = -1. * shift_at_midwav, 
                    scalefac = scalefac, fakenameroot = fakenameroot)
                   
               # set the header of our clean spectrum to look at this
               hedit("tempspec2","refspec1",fakenameroot,add="yes",update="yes",verify="no")
               # at this point add in a note about the wavelength correction, too.
               hedit("tempspec2","wavcorr",correction_text,add="yes",update="yes",verify="no")
               
               # Finally, bin the spectrum properly.
               
               dispcor("tempspec2", dispname, linearize = 'yes', w1 = thisw1, dw = thisdw, 
                    nw = thisnw, w2 = "INDEF", confirm="no", ignoreaps = "yes", listonly = "no",
                    verbose = "yes")
 

           else :
           
    
               # The first thing we do here is to write the dispersion coefficients into the
               # header, so we can see where the night-sky lines (or whatever) end up
               # when we use that calib.
    
               # Note that to install a wavelength calib, you need to copy the calib spec into your
               # quick-look directory, AND create a directory "database" into which you
               # stick the "idxxxx" file, where xxxx is the image name of the calib spec.
            
               refspectra(outputimage + ".ms",references = calibspec,
                  ignoreaps = "yes", sort = "", group = "", time = "no",
                  override = "yes", confirm = "no", assign = "yes", verbose = "yes")
    
               dispcor(outputimage + ".ms","tempspec",linearize="no",
                database = "database", w1 = "INDEF", w2 = "INDEF",
                dw = "INDEF", nw = "INDEF", confirm = "no", ignoreaps = "yes",
                listonly = "no", verbose = "yes")
               
               # "tempsec" has wavelength coeffs in header now.
               
               # We'll need values of some of the dispersion parameters later.
               # convel gives a way of reading them out of the header, which 
               # we employ here:
               
               # cv is the convel package; this reads the dispersion solution
               # from the temporary file that has been dispcor'd but not
               # linearized.
               
               # hdu = fits.open('tempspec.fits')
               # hdr = hdu[0].header
               # dispsol = cv.dispersionsoln(hdr, verbose=False) 
               # hdu.close() 
    
               # reference_soln = dispsol.dispersion_funcs[-1]
               
               # diagnostic
               #for i in range(0,reference_soln.ncoeffs) :
               #    print "coeff %d : %f " % (i, reference_soln.coeffs[i])
               
               # referencewav = reference_soln.coeffs[0]  # central wavelength
               # referencespan = reference_soln.coeffs[1] # span in Angstroms
    
               # Measure the wavelengths of the night sky lines in the dispcor'd
               # (but not rebinned!) spectrum.
            
               deltawavs = {}   # dictionary of wavelength shifts keyed to rest wavelength
               waverrs = {}        # rough estimated error by wavelength
               delta_5577 = 1000.  # keep these out separately to use in constant offset.
               delta_6300 = 1000.  # shifts, which are a little better than nothing.
    
               # I have the structure here to try for nightsky lines only when it's 
               # dark, but I've basically turned it off by setting the twilight limit
               # to be extremely bright.  In future I'll just take adjacent HgNe specs adjacent in 
               # bright twilight.
    
               if obs.twi < 10. :  # -- try for several lines
     
                   for n in nswavelengths :
    
                       # The object data are all IRAF multispecs; the object is in 'band 1' which is
                       # index zero, the sky in 'band 3' which is index 2 in the zero-indexed data array.
                       # Note that helio correction is not applied, and  shouldn't be.  
                       # Note also that setting the "raw_error" flag does a crude
                       # estimate of the velocity uncertainty by assuming the sky spectrum follows
                       # poisson statistics with a gain of 1; background is modeled as a running
                       # median.  This is not accurate, but should be reasonable for fit weighting.
                   
                  #    (vel,err) = cv.specvel("tempdisp.fits",2,n,half_wid = 6., linwid=7.,

                       # half_wid, linwid etc tuned a bit empirically but should perhaps be
                       # made adaptive.

                       (vel,err) = cv.specvel("tempspec.fits",2,n,half_wid = 5., linwid=5.,
                          search_wid=20., rootsearch = True, do_error = False, raw_error = True, helio_correct = False)
    #                   print("wav %f : vel %f, err %f" % (n,vel,err))
    
                       # convert the velocity to a wavelength shift.
    
                       delta = (vel / lightsp) * n
                       waverr = err * n / lightsp
                   
                       if abs(n - 5577.3) < 1. : delta_5577 = delta  # save this to revert to simple shift.
                       if abs(n - 6300.3) < 1. : delta_6300 = delta  
                       
                       # censor out velocities with large estimated errors, which I'll set as 30
                       # km/s based on some experimentation.
    
                       if abs(err) < 30. and abs(waverr) > 0. :  # also avoid zero errs (returned when 
                                                       # specvel goes haywire, apparently). 
                           deltawavs[n] = delta
                           waverrs[n] = waverr
                   
                   # stack the results in lists ordered by wavelength.
                   # This may be overly complicated by it doesn't matter much.
    
                   restwavs = deltawavs.keys()
                   restwavs.sort()
                   shiftarr = []
                   error_arr = []
                   
                   for r in restwavs :
                       shiftarr.append(deltawavs[r])
                       error_arr.append(waverrs[r])
                   
                   # optionally view result.
    
                   if args.review :
    
                      fig = plt.figure()
                      cid = fig.canvas.mpl_connect('key_press_event',onpress)
    
                      plt.plot(restwavs, shiftarr,'bo')
                      plt.errorbar(restwavs,shiftarr,error_arr,fmt='o')
    
                   shiftarr_uncorr = shiftarr
                   restwavs_orig = restwavs
    
                   # Fit a robust straight line, iteratively excluding residuals too large.
    
                   if len(restwavs) > 2 : 
                       # print "restwavs ",restwavs
                       # print "shiftarr ",shiftarr
                       # print "error_arr",error_arr

                       # again, maxresid = 0.2 seems OK empirically.

                       (shiftmodel, nkept, xdeleted, ydeleted,rms) = robust_straightline(restwavs,
                                  shiftarr,error_arr,maxresid=0.2)
    
                       if args.review :  # optionally review

                           # overstrike deleted points
                           plt.plot(xdeleted,ydeleted,'x',markersize=15)
     
                           # plot the fitted straight line
                           y1 = np.polyval(shiftmodel, restwavs[0])
                           y2 = np.polyval(shiftmodel, restwavs[-1])
                           plt.plot([restwavs[0],restwavs[-1]],[y1,y2],'-')
        
                       # print "shiftmodel:",  shiftmodel
                        
                       # shiftmodel[1] is the y-intercept at wavelength zero and 
                       # shiftmodel[0] is the slope.  Find the shift at the middle of 
                       # the spectrum from this, and also the scale factor to apply to 
                       # the results.
                       shift_at_midwav = shiftmodel[0] * referencewav + shiftmodel[1]
                       scalefac = 1.00 - shiftmodel[0]
                       print "kept ",nkept," pts, shift at mid:", shift_at_midwav," scalefac: ",scalefac
        
                   else :
                       nkept = len(restwavs)
                       print "Too few line centers survive for a fit."
    
                   # Revert if the fit isn't much good
                   # Save a note for the header of output.
    
                   if nkept < 3 or rms > 0.35 :  
                       if delta_5577 < 999. : 
                           shift_at_midwav = delta_5577
                           scalefac = 1.00
                           print "POOR FIT, doing a simple 5577 shift with no stretch."
                           correction_text = "Wavelengths shifted %5.3 A using 5577"
                       else : 
                           shift_at_midwav = 0.
                           scalefac = 1.00
                           print "POOR FIT and 5577 no good, so no correction."
                           correction_text = "Could not apply night sky correction"
    
                   else :
                       correction_text = "night sky zpt: %6.3f A, scalefac: %8.6f, %d pts" % \
                              (shift_at_midwav, scalefac, nkept)
    

                   # Testing! 
                   #print "ARTIFICIALLY setting shift to +100."
                   #shift_at_midwav = 100.
                   # scalefac = 1.00
    
                   diagnosticlist.write("%s  %6.0f  %6.2f  %2d  %6.2f  %6.3f  %9.6f\n" %
                           (outputimage + ".ms",camfoc, benchtemperature, nkept, rms, 
                             shift_at_midwav, scalefac))
    
                   if args.review : 
                       plt.title("%s - %s - %5.0f s - %4.1f mag" % (outputimage,objname,exptime,obs.twi))
                       plt.xlabel("Wavelength")
                       plt.ylabel(r"$\Delta \lambda$")
                       plt.show()
                    
                   print "tweaking with scalefac = %8.6f, shift %f" % (scalefac,shift_at_midwav)
     
                   tweak_dispersion(calibspec,ctrshift = -1. * shift_at_midwav, 
                       scalefac = scalefac, fakenameroot = fakenameroot)
                   
                   # this REALLY needs 'add = "yes"' or dispcor fails horribly after a few spectra.
                   hedit("tempspec2","refspec1",fakenameroot,add="yes",update="yes",verify="no")
                   # at this point add in a note about the n/s correction, too.
                   hedit("tempspec2","nscorr",correction_text,add="yes",update="yes",verify="no")
                   
                   # Finally, apply the tweaked wavelength calibration and bin the spectrum.
                   
                   gc.collect()
                   dispcor("tempspec2", dispname, linearize = 'yes', w1 = thisw1, dw = thisdw, 
                        nw = thisnw, w2 = "INDEF", listonly='no',verbose='yes', ignoreaps = 'yes')
    
               # Vestigial stuff for only doing specified sky brightness.
                   
               elif obs.twi < 8. :  # Just do 5577. which is strong in twilight
                   pass
    
               else :  # don't shift.
                   pass
                   
               # for quality check, measure the lines again and optionally plot.
               
               deltawavs = {}   # dictionary by rest wavelength
               errors = {}
               
               for n in nswavelengths :
                   # band numbers are zero indexed so spec is zero, sky is 2.
               
                   (vel,err) = cv.specvel(dispname,2,n,half_wid = 6., search_wid=3., 
                         do_error = False, raw_error = True, helio_correct = False)
               
                   # get the wavelength shift from the velocity.
                   delta = (vel / lightsp) * n
                   # print n, vel, delta, err
                   deltawavs[n] = delta
                   errors[n] = err * n / lightsp
               
               # stack the results in ordered lists, again may be overly elaborate.
               
               restwavs = deltawavs.keys()
               restwavs.sort()
               shiftarr = []
               error_arr = []
               
               for r in restwavs :
                   shiftarr.append(deltawavs[r])
                   error_arr.append(errors[r])
               
               #print "shiftarr:",shiftarr
               #print "error_arr",error_arr
               #print "len(shiftarr), len(error_arr)",len(shiftarr), len(error_arr)
               #print "len(restwavs) = ",len(restwavs)
               
               # optionally view result -- used this to tweak convel parameters.
               
               if args.review : 
    
                   # acceptfit is a dictionary that counts as a 'mutable object' that
                   # can be modified by the call of 'onpress'.  It's rather deep in the 
                   # pythonic weeds -- used for handing back an 'x', 'r', or 'd', any 
                   # of which will erase the output dxxxxx.fits file and therefore 
                   # reject the adjustment.
    
                   acceptfit['key'] = 'A'  # default is to accept result.
                   
                   fig = plt.figure()
                   cid = fig.canvas.mpl_connect('key_press_event',onpress)
                   plt.plot(restwavs, shiftarr,'bo')
                   plt.errorbar(restwavs, shiftarr, error_arr,fmt='o')
                   plt.plot(restwavs_orig, shiftarr_uncorr,'rs')
                   plt.title("%s - %s - %5.0f s - %4.1f mag" % (dispname,objname,exptime,obs.twi))
                   plt.xlabel("Wavelength")
                   plt.ylabel(r"$\Delta \lambda$")
                   plt.show()
    
                   
                   # print("acceptfit['key'] = ",acceptfit['key'])
                   if acceptfit['key'].upper() == 'X' or \
                     acceptfit['key'].upper() == 'R' or \
                     acceptfit['key'].upper() == 'D' :
                       imdelete(dispname + ".fits") 
                       rejectedlist.write("%s\n" % outputimage)
     
               # sys.exit()    # uncomment to test a single spectrum placed at top of input list.
           
           # loop for individual spec ends here
 
       rejectedlist.close() 
       diagnosticlist.close()

       print "Finished processing spectra with setup %s." % k
        
