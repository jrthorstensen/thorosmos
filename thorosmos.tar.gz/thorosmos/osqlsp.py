#!/usr/bin/env python

# This is designed to be used from within pyraf -- it has its
# own task parameter file in the iraf directory called
# "osqlsp.par".  
# To use it 
#  -- make your own copy in the local directory
#  -- start pyraf by typing 'pyraf'
#  -- load the task by typing 
#             pyexecute("osqlsp.py")

# The task 
#  -- subtracts the bias using the bias strips, and 
#     trims away the bias strips ; this requires disassembling 
#     and reassembling the image (the original is untouched).
#  -- Uses image header parameters to determine the setup (i.e.,
#     slit, disperser, format); sets heliocentric keywords.
#  -- Runs the noao/imred/specred "apall" task on the result
#     to extract a 1-d, sky-subtracted spectrum.
#  -- Optionally applies a previously-existing wavelength calib
#  -- Optionally uses night-sky lines to shift and stretch the spectrum
#     to account for spectrograph flexure.

# Here's how to set up osql.py to get wavelength-calibrated
# spectra:
# -- derive a wavelength calibation from any comparison, say
#      gg123.0001 ; this will be a natural byproduct of a night's
#      reduction, so it's easy to set up for the 2nd night ... 
# -- If you didn't do the wavelength fit in the quicklook directory
#      you're using, be sure to copy gg123.0001 (or whatever) _and_
#      the file database/idgg123.0001 (or whatever) over; the 
#      id file should go in the database subdirectory of your 
#      quicklook directory.

#  Other notes:

# -- As part of the setup, you have to make sure that you have
#      osqlsp.par in the /lhome/obs24m/iraf/uparm directory.

from pyraf import iraf
from iraf import images,imcopy,imdelete,imrename,hselect,hedit # imtile
# from iraf import astutil,asthedit
# from iraf import noao,imred,bias,linebias
from iraf import noao,specred,apall,splot,refspectra,dispcor,specshift
# from iraf import rvsao, convrv
import convel

# from cooclasses import *

from astropy.io import fits
import numpy as np
import osbias as osb
import osmosexposure as osexp
import oswave as osw

import os  # python operating system module, not osmos.
 
def get_config() : 
    try : 
        inf = open("osmosspecred.config","r") 
    except :  # for unknown reasons this needs python3 style print
              # statements on the laptop.  YMMV.
        print("You need a file called 'osmosspecred.config'.")
        print("This must have these defined (with examples here):")
        print("PREFIX | kf    # two-letter prefix for reduced")
        print("RAWPARENT | /home/thorsten/iraf/dec18/osmosraw ")
        print( ".... exiting.")
        sys.exit()

    prefix = None   #initialize to allow leaving them out
    rawdir = None
    setups_to_omit = []
    # noflatfield = []   # setups which you won't bother to flatfield
    displine = {}   # dispersion line for finding spec (usually the col
                     # containing H-alpha, keyed to spectral setup.
    wavecal = {}    # name of wavecal spectrum, keyed to setup.  These must
                    # already have had ident run and have excellent solutions.
    flatimage = {}  # flatfield image names, keyed to setup.
    w1 =      {}    # wavelength binning parameters, also keyed to setup. 
    dw =      {}
    nw =      {}
    lowpixblue = {} # direction for night-sky shifting of spec.

    for l in inf : 
        if l[0] != '#' :
            x = l.split('|')
            if x[0].upper().find('PREFIX') > -1 : 
                if x[1].find("#") :
                    y = x[1].split('#')
                    prefix = y[0].strip()
                else : 
                    prefix = x[1].strip()
            if x[0].upper().find('RAWPARENT') > -1 :
                if x[1].find('#') :
                    y = x[1].split('#')
                    rawdir = y[0].strip()
                else : 
                    rawdir = x[1].strip()

            if x[0].upper().find('OMITSETUP') > -1 :
                if x[1].find('#') :
                    y = x[1].split('#')
                    setups_to_omit.append(y[0].strip())
                else : 
                    setups_to_omit.append(x[1].strip())

#            if x[0].upper().find('NOFLATFIELD') > -1 :
#                if x[1].find('#') :
#                    y = x[1].split('#')
#                    noflatfield.append(y[0].strip())
#                else : 
#                    noflatfield.append(x[1].strip())

            if x[0].upper().find('FLATIMAGE') > -1 :
                flatimage[x[1].strip()] = x[2].strip()
             #   print("assigned flatimage[%s] = %s" % (x[1].strip(),x[2].strip()))

            if x[0].upper().find('DISPLINE') > -1 :
                displine[x[1].strip()] = int(x[2])

            if x[0].upper().find('WAVECAL') > -1 :                
                wavecal[x[1].strip()] = x[2].strip()

            if x[0].upper().find('W1') > -1 :                
                w1[x[1].strip()] = float(x[2])

            if x[0].upper().find('DW') > -1 :                
                dw[x[1].strip()] = float(x[2])

            if x[0].upper().find('NW') > -1 :                
                nw[x[1].strip()] = int(x[2])

            if x[0].upper().find('LOWPIXBLUE') > -1 :  # 1 = low pixels are blue end
                lowpixblue[x[1].strip()] = int(x[2])           # -1 = low pixels are red end

    return (prefix, rawdir, setups_to_omit, flatimage,
             displine, wavecal, w1, dw, nw, lowpixblue)

prefix, rawdir, setups_to_omit, flatimage, displine, wavecal, \
   w1, dw, nw, lowpixblue = get_config()

w2 = "INDEF"  # always want a fixed number of pixels in the output spectrum.

def osqlsp(imnum,datapath, prefix, flatten, thorap,
   dowavecal,donscorr) :

   if datapath[-1] != "/" :     # be sure there's a trailing slash in path.
      datapath = datapath + "/"

   inputimage = datapath + "%s%04d" % (prefix,imnum)
   outputimage = "x%04d" % imnum
   inputimname = inputimage + ".fits"
   outputimname = outputimage + ".fits"
   
   # print "input and output images are:",inputimage,outputimage

   try :   # want "clobber" for this, always.
      os.system("rm %s.fits" % (outputimage))
   except : 
      pass
   try :   # want "clobber" for this, always.
      os.system("rm %s.ms.fits" % (outputimage))
   except :
      pass

   osb.biasquads(inputimname, outputimname)

   ose = osexp.osexposure(inputimname)
   ose.set_reduced_name('x')    
   ose.setinfo()  # sets e.g. helio corrections and much more

   # Flatten using astropy (i.e. numpy) rather than IRAF

   print(flatimage)
   print( ose.setup)
   if flatten : 
       if flatimage[ose.setup].find('.fits') < 0 : 
           flatname = flatimage[ose.setup] + ".fits"
       else : flatname = flatimage[ose.setup]
       hduflat = fits.open(flatname)
       flatarray = hduflat[0].data
       if outputimname.find('.fits') < 0 : 
           im = outputimname + ".fits"
       else :  im = outputimname 
       hduim = fits.open(im, mode = 'update')
       hduim[0].data = hduim[0].data / flatarray 
       hduim.flush()
       hduflat.close()
       hduim.close()
           
       print("flatfielded using %s." % (flatimage[ose.setup]))

   # set up to extract the 1-d spectrum.

   specred.dispaxis = 1 # spec is 'on its side' 
   apall.output = outputimage
   apall.references = outputimage
   apall.profiles = outputimage
   apall.apertures = ""
   apall.interactive = "yes"
   apall.format = "multispec"
   apall.find = "yes"
   apall.recenter = "yes"
   apall.resize = "yes"
   apall.edit = "yes"
   apall.trace = "yes"
   apall.fittrace = "yes"
   if thorap :
      apall.extract = "no"
   else :
      apall.extract = "yes"
   apall.extras = "yes"
   apall.review = "no"
   apall.line = displine[ose.setup]
   apall.nsum = -40
   apall.lower = -10.
   apall.upper = 10.
   apall.b_function = "legendre"
   apall.b_order = 3
   apall.b_sample = "-150:-50,50:150"
   apall.b_naverage = -3
   apall.b_niterate = 1
   apall.b_low_reject = 3.0
   apall.b_high_reject = 3.0
   apall.b_grow = 1.
   apall.nfind = 1
   apall.llimit = "INDEF"
   apall.ulimit = "INDEF"
   apall.ylevel = 0.3
   apall.peak = "yes"
   apall.bkg = "yes"
   apall.r_grow = 1.5
   apall.t_nsum = 60
   apall.t_step = 50
   apall.t_nlost = 4
   apall.t_function = "legendre"
   apall.t_order = 3
   apall.t_sample = "*"
   apall.t_niterate = 1
   apall.t_low_reject = 3.0
   apall.t_high_reject = 3.0
   apall.background = "fit"
   apall.skybox = 1
   apall.weights = "variance"
   apall.pfit = "fit1d"
   apall.clean = "yes"
   apall.saturation = 60000
   apall.readnoise = 8
   apall.gain = 3
   apall.usigma = 3.0
   apall.lsigma = 3.0
   
   # and, finally, interact with the data.

   apall(outputimage)

   if thorap :
      os.system("thorapsum.osmos %s" % outputimage)

   if not dowavecal :
      splot(outputimage + ".ms")

   else :
      osw.setwav(outputimage + ".ms",wavecal[ose.setup],ose.setup, do_nscorr = donscorr) 
      splot("d" + outputimage)
   
# parfile = iraf.osfn("/lhome/obs24m/iraf/uparm/osqlsp.par")
# parfile = iraf.osfn("/lhome/obs24m/iraf/uparm/osqlsp.par")
parfile = iraf.osfn("/home/thorsten/iraf/uparm/osqlsp.par")
t = iraf.IrafTaskFactory(taskname = "osqlsp", value = parfile,
     function = osqlsp)

    
