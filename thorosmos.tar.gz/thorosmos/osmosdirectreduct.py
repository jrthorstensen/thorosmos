#!/usr/bin/env python
"""osmosdirectreduct.py [--listonly --firstdate 181213 --lastdate 181219]
     task to parse and process osmos direct raw data.
   -- use '--listonly' to see what it'll try to do and get 'official'
        names of the setups it finds.
   -- built on osmosspecreduct.py, which in turn is built on 
        osmosinventory code.
   -- edit "osmosdirectred.config" in same directory before using.
   -- the individual nightly directories should have integer names,
      eg 181213 (yymmdd usually).
   -- You can optionally specify a range of dates; firstdate and lastdate
       default to 0 and 9999999 so the default includes all subdirectories.
   -- WHAT IT DOES:
      -- Parses the data out into direct images (no disperser and 
            no slit) and spectra (disperser and slit); throws away
            slit + no disperser slit location images, and any images 
            with 'focus' in the title.
      -- Constructs names for the various setups by joining the 
            filterids and region name into a single string.
      -- loops through these setups; for each one, looks for a pre-
            existing flatfield image, e.g, flat_4x1k_Open_V.fits, and
            if it doesn't find one, constructs a new one
            [If no flats exist or they're inadequate you can turn
             off flatfielding for that setup in the config file.]
      -- biases, cross-talk corrects (without making a saturation mask;
            you can set that in the source code if you want or 
            add another flag to the config file and write into the code)
      -- Divides by the flatfield
      -- Finally, runs a script to detect stars, match to the PPMXL, and
            install WCS in the object images. 

   NOTE: This assumes that each readout region and binning have their 
     own direct flatfields.  In principle it should be possible to 
     flatfield smaller regions using image sections of larger flats --
     e.g., to flatfield roi1k images with a subsection of the roi4x1k 
     flat in the same filter.  I have not implmented this yet.  
     Computing the subarray limit should be a bit simpler than the 
     general case because the ROIs are all centered on the middle of 
     the chip.  Mostly need the various gingerbread establishing 
     that this or that ROI/filter is a subarray of another ROI/filter. 
   
"""

import sys
from pyraf import iraf
from iraf import hselect
from cooclasses import *
import glob
import osbias as osb
import osflatfield as osf
import os
from copy import deepcopy

import numpy as np
import fitmatchradec as fmrad

import argparse

parser = argparse.ArgumentParser(description="bias and flatfield OSMOS raw data.")
parser.add_argument("--firstdate",help="first subdir. to parse, eg 121813",type=int,default=0)
parser.add_argument("--lastdate",help="last subdir. to parse, eg 121817",type=int,default=9999999)
parser.add_argument("--listonly",help="List without computing",action="store_true")
parser.add_argument("--wcsmatch",help="Try for wcs solution",action="store_true")

args = parser.parse_args()
# 
# ################################################################
# 
# # The inner and outer slits are almost 6 arcmin from the 
# # telescope axis.  Header coords are those of the telescope axis.
# # This bit of code infers the RA and dec of the target from the
# # slit identification, the telscope coordinates, and the rotator 
# # angle.
# 
# class rotatedobs :
# 
#    def __init__(self,telaxiscel,rotangle):
#       self.targcel = None   # not matched yet
#       self.telaxiscel = telaxiscel
#       self.rotangle = rotangle
#       self.telaxiscel.selfprecess(2019.)
#       self.implied_obj_cel = None
#       self.implied_obj_miss = None
#       self.implied_obj_xieta = None   # [xi, eta] of implied position around true 
#       self.slit = 1  # inner; 0 is center, -1 is outer.  
#                      # inner is at x = -342, y = 0; outer at x = +345, so 
#                      # it's close enough to use an integer.
# 
#    def setxieta(self):
#       [xi,eta] = fmrad.tostdpy(self.targcel.ra.val,self.targcel.dec.val,
#             self.telaxiscel.ra.val,self.telaxiscel.dec.val)
#       self.xi = xi
#       self.eta = eta   # an attempt to debug ... 
# 
#    def guess_obj_from_tel(self) :
#       # given telescope coords plus rotator, guess object coords
#       if self.slit == 1 :
#           X = -342.  # inner
#       elif self.slit == -1  :
#           X = 345.   # outer
#       else :
#           X = 0.     # center, in which case this isn't needed.
#       Y = 0.      # position of inner slit
# #      rot = -1. * self.rotangle / cooconsts.DEG_IN_RADIAN
#       rot = self.rotangle / cooconsts.DEG_IN_RADIAN
#       Xprime = np.cos(rot) * X + np.sin(rot) * Y
#       Yprime = -1. * np.sin(rot) * X + np.cos(rot) * Y
#       raobj, decobj = fmrad.greek2radec(Xprime,Yprime,self.telaxiscel.ra.val,
#               self.telaxiscel.dec.val)
#       self.implied_obj_cel = celest([raobj,decobj,2019.])
# #      self.implied_obj_cel.selfprecess(2000.)
#       if self.targcel != None : # can be used to check pointing if targcel set externally
#          self.implied_obj_miss = subtendang(self.targcel.ra.val,self.targcel.dec.val,
#                          self.implied_obj_cel.ra.val,self.implied_obj_cel.dec.val) * cooconsts.ARCSEC_IN_RADIAN
#          self.implied_obj_xieta = fmrad.tostdpy(self.implied_obj_cel.ra.val, self.implied_obj_cel.dec.val,
#               self.targcel.ra.val,self.targcel.dec.val)
#          print "xieta = ",self.implied_obj_xieta[0],self.implied_obj_xieta[1]
# 
############### end of target position inference code ############

#### Code to read reduction configuration from osmosspecred.config ######

def get_config() : 
    try : 
        inf = open("osmosdirectred.config","r") 
    except :
        print "You need a file called 'osmosspecred.config'."
        print "This must have these defined (with examples here):"
        print "PREFIX | kf    # two-letter prefix for reduced"
        print "RAWPARENT | /home/thorsten/iraf/dec18/osmosraw "
        print ".... exiting."
        sys.exit()

    prefix = None   #initialize to allow leaving them out
    rawdir = None
    setups_to_omit = []
    noflatfield = []   # setups which you won't bother to flatfield
    displine = {}   # dispersion line for finding spec (usually the col
                     # containing H-alpha, keyed to spectral setup.
    wavecal = {}    # name of wavecal spectrum, keyed to setup.  These must
                    # already have had ident run and have excellent solutions.

    # This is a rather verbose way of parsing this but it works, and
    # it's easy to customize.

    for l in inf : 
        if l[0] != '#' :
            x = l.split('|')
            if x[0].upper().find('PREFIX') > -1 : 
                if x[1].find("#") :
                    y = x[1].split('#')
                    prefix = y[0].strip()
                else : 
                    prefix = x[1].strip()
            if x[0].upper().find('RAWPARENT') > -1 :
                if x[1].find('#') :
                    y = x[1].split('#')
                    rawdir = y[0].strip()
                else : 
                    rawdir = x[1].strip()

            if x[0].upper().find('OMITSETUP') > -1 :
                if x[1].find('#') :
                    y = x[1].split('#')
                    setups_to_omit.append(y[0].strip())
                else : 
                    setups_to_omit.append(x[1].strip())

            if x[0].upper().find('NOFLATFIELD') > -1 :
                if x[1].find('#') :
                    y = x[1].split('#')
                    noflatfield.append(y[0].strip())
                else : 
                    noflatfield.append(x[1].strip())

    return (prefix, rawdir, setups_to_omit, noflatfield)

prefix, rawdir, setups_to_omit, noflatfield = get_config()

class osexposure :
   # information on a single exposure.
   def __init__(self, fname) :
      self.fname = fname
      self.localfname = os.path.split(fname)[-1]
      try :
         self.parentdir = os.path.split(fname)[-2]
      except :
         self.parentdir = None
      self.reducedname = None  # with the standard prefix (usually two letters)
      self.num = None          # sequence number (int)
      self.telescope_cel = None # telescope axis coords (from header)
      self.cel = None           # inferred coordinates of target
      self.rotangle = None
      self.title = None
      self.imagetyp = None
      self.isfocus = False
      self.exptime = None
      self.jd = None
      self.filter1 = None 
      self.filter1id = None
      self.filter2 = None 
      self.filter2id = None
      self.disperser = None
      self.slit = None 
      self.naxis1 = None
      self.naxis2 = None
      self.roi = None
      self.mirror = None 
      self.lamps = None
      
   def printall(self) :  # mostly for diagnostics.
      print "filename: ", self.fname
      print "tel coords:",self.telescope_cel.summarystring()
      # print "coords:", self.cel.summarystring()
      print "rotangle ", self.rotangle
      print "object:", self.title
      print "type  :",  self.imagetyp 
      print "exp, jd, ",self.exptime,self.jd
      print "filter1 ", self.filter1, self.filter1id 
      print "filter2 ", self.filter2, self.filter2id
      print "disperer", self.disperser
      print "slit : ", self.slit
      print "format : ", self.naxis1, " x ",self.naxis2
      print "mirror, lamps: ", self.mirror, self.lamps

   def set_reduced_name(self, prefix) :
      root = self.localfname.replace('.fits','')
      # print root
      x = root.split('.')
      # print x, x[-1]
      self.num = int(x[-1])   # this means originals must be e.g. b.0001.fits
      self.reducedname = prefix + "%04d" % (self.num)
      self.reducedname = self.reducedname.strip()

# This might be reinstated by looking ahead at whether a spec was taken
# but for now that's much too painful,
 
#    def set_target_cel(self) :  # assumes info has been loaded.
#       ro = rotatedobs(self.telescope_cel,self.rotangle)
#       ro.slit = 0
#       try :
#            if(self.slit[1].find('nner') > -1) : 
#                  ro.slit = 1
#            elif(self.slit[1].find('uter') > -1) :
#                  ro.slit = -1 
#       except :
#            pass 
# 
#       ro.guess_obj_from_tel()
# 
#       self.cel = deepcopy(ro.implied_obj_cel)  # just to be sure.
# 
#       self.telescope_cel.selfprecess(2000.)
#       self.cel.selfprecess(2000.)
            

###############

class objgrp :  # all observations of a single object, assigned by proximity

   def __init__(self, osexp) :
      self.osexps = [osexp]
      self.cel = osexp.cel
      self.titles = [osexp.title]

###############

# print "searching:", "%s/" % (rawdir)

dirlist = glob.glob('%s/*' % (rawdir))   # lists all subdirectories immediately below.

included_dirs = []  # within range of dates ...
dirnums = []        # useful later

for fullpath in dirlist :
   d = os.path.split(fullpath)[-1]
   d = d.replace("/","")
   try :
      dnum = int(d)
      if dnum > 150000 and dnum < 400000: # start of 2015 to be conservative 
         if dnum >= args.firstdate and dnum <= args.lastdate :
            included_dirs.append(fullpath)
      dirnums.append(dnum)
   except :
      pass

included_dirs.sort() 

print "Including directories: " 
for d in included_dirs :
   print d

# Set up lists of various kinds of exposures.

all_exposures = []
all_objectexps = []
all_groups = []
all_directexps = []
all_dirflats = []
all_misflats = []
all_slitflats = []
all_comps = []
all_biases = []
all_darks = []

all_objgrps = []    # object exposure groups, assigned by proximity.

roidict = {(1088, 1024) : "1x1k", (4128, 1016) : "4x1k", (4128,4064) : "4x4k",
           (1080, 4064) : "1x4k", (2064, 508) : "4x1B"}

# slitdispdict = {}   # spectral exposure dictionary keyed
directsetupdict = {}  # dictionary of direct imaging setups
allobjdict = {}     # information held for archiving, keyed by image number

#  Scan all the images in all the directories; make osexposures for each of them.

for d in included_dirs :
   print d
   fitsfiles = glob.glob(os.path.join(d,"*.fits"))
   fitsfiles.sort()
   for f in fitsfiles :
      hselout = hselect(f,"ra,dec,equinox,exptime,imagetyp","yes",Stdout=1)
      x = hselout[0].split('\t')
      if len(x) == 5 :   # avoid screwed-up images e.g. those biases that didn't see the telescope
         osexp = osexposure(f)
         osexp.telescope_cel = celest([x[0].strip(),x[1].strip(),x[2].strip()])
         if osexp.telescope_cel.equinox != 2000. : osexp.telescope_cel.selfprecess(2000.)
         osexp.exptime = float(x[3].strip())
         osexp.imagetyp = x[4].strip()
     #    print hselout
     #    print osexp.cel.summarystring(),osexp.exptime,osexp.imagetyp
            
         hselout = hselect(f,"title,jd,filter1,filtid1,filter2,filtid2,dispid,rotangle","yes",Stdout = 1)
         x = hselout[0].split('\t')
         osexp.title = x[0]
         if osexp.title.upper().find("FOCUS") > -1 : osexp.isfocus = True
         osexp.jd = float(x[1])
         osexp.filter1 = int(x[2])
         osexp.filter1id = x[3].strip()
         osexp.filter2 = int(x[4])
         osexp.filter2id = x[5].strip()
         osexp.disperser = x[6]
         osexp.rotangle = float(x[7].strip())

         hselout = hselect(f,"slitid,mirror,lamps,naxis1,naxis2","yes",Stdout = 1)
         x = hselout[0].split('\t')
         osexp.slit = x[0].split()
         osexp.mirror = x[1].strip()
         osexp.lamps = x[2].strip()
         osexp.naxis1 = int(x[3])
         osexp.naxis2 = int(x[4])

#         osexp.set_target_cel()

#         print osexp.slit,osexp.rotangle,'tel:',osexp.telescope_cel.summarystring(),'obj',osexp.cel.summarystring()

        # print osexp.naxis1, osexp.naxis2
         try : 
            osexp.roi = roidict[(osexp.naxis1, osexp.naxis2)]   # tuple works as key
         except : 
            print "unknown ROI, naxis1/2 = ",osexp.naxis1,osexp.naxis2
            print "*** This will be skipped. *** "
            osexp.roi = "X"  # X, the unknown
         all_exposures.append(osexp)

         if osexp.slit[0].upper() == "OPEN" and  osexp.disperser.upper() == "OPEN" and osexp.roi != "X":
             directsetup = osexp.roi + "_" + osexp.filter1id + "_" + osexp.filter2id
             if directsetupdict.has_key(directsetup) : 
                 directsetupdict[directsetup].append(osexp)
             else : 
                 directsetupdict[directsetup] = [osexp]

# Determine type of each exposure, using imagetyp keywords and internal evidence from
# lamps, etc.   Load each to the appropriate list.

         if osexp.imagetyp == "OBJECT" and osexp.roi != "X":
           # guard against some mistakes e.g. mislabeled comps and flats
           # retained from spectrum code but these are harmless checks I think.
            if osexp.mirror == "IN" :  # can't be an object with the mirror in!
               if osexp.lamps == "Flat" and osexp.disperser.upper() != "OPEN" and osexp.slit[0].upper() != "OPEN" : 
                  osexp.imagetyp = "FLAT"
               if osexp.lamps != "Flat" and osexp.lamps != "Off" and osexp.disperser.upper() != "OPEN" \
	                    and osexp.slit[0].upper() != "OPEN" : 
                  osexp.imagetyp = "COMP"
               print "Mirror in on object:", osexp.fname, osexp.lamps
            if osexp.imagetyp == "OBJECT" :  # still, after error corrections ... 
               # take only the direct images.
               if osexp.mirror != "IN" and osexp.disperser.upper() == "OPEN" and osexp.slit[0].upper() == "OPEN" \
                  and not osexp.isfocus : 
                  all_objectexps.append(osexp)  

         # capitalization of Open, open etc is inconsistent
         if osexp.imagetyp == "FLAT"  and osexp.roi != "X" :
            # print "mirror, disperser, slit", osexp.mirror, osexp.disperser, osexp.slit
            if osexp.mirror == "OUT" : 
               if osexp.disperser.upper() != "OPEN" and osexp.slit[0].upper() != "OPEN" : 
                  all_slitflats.append(osexp)
               if osexp.disperser.upper() == "OPEN" and osexp.slit[0].upper() == "OPEN" :
                  all_dirflats.append(osexp)
            if osexp.mirror == "IN" : 
               if osexp.disperser.upper() != "OPEN" and osexp.slit[0].upper() != "OPEN" : 
                  all_misflats.append(osexp)

         if osexp.imagetyp == "COMP" and osexp.roi != "X":
            # print osexp.lamps
            all_comps.append(osexp)

         if osexp.imagetyp == "BIAS" and osexp.roi != "X": 
            all_biases.append(osexp)
   
         if osexp.imagetyp == "DARK" and osexp.roi != "X":
            all_darks.append(osexp)

print "You have %d direct object exposures, " % (len(all_objectexps))
print "         %d MIS flats, " % (len(all_misflats))
print "         %d slit balance flats, " % (len(all_slitflats))
print "         %d comp exposures, " % (len(all_comps))
print "         %d direct flats, " % (len(all_dirflats))
print "         %d dark exposures, " % (len(all_darks))
print "     and %d bias exposures. " % (len(all_biases))

def cels_match(cel1, cel2, arcmin_tolerance) : 
   # says whether two cels match within tolerance.
   # filter to avoid expensive comparison
   if abs(cel1.ra.val - cel2.ra.val) > 0.1 : return False   # ignore wrap
   if abs(cel1.dec.val - cel2.dec.val) > 0.3 : return False 
   dist = subtendang(cel1.ra.val,cel1.dec.val,cel2.ra.val,cel2.dec.val) 
   rad_tol = arcmin_tolerance / 3437.7  # arcmin per radian 
   if dist < rad_tol : return True
   else : return False


print " "
print " "
print " ***************** DIRECT SETUPS  *************** " 
print " " 
print " " 

# List the desired filter/format combinations, loop over them,
# and process each one as you go.

todokeys = directsetupdict.keys()

# print "Before removal: todokeys = ",todokeys

for k in setups_to_omit :
   try :
       todokeys.remove(k)
       print("removed setup %s from processing." % (k))
   except :
       print("Couldn't remove setup %s" % (k))

for k in todokeys : 

    print " "
    print " ******** ",k," ********* "
    print " "
 
    if k in noflatfield :
        doflatfield = False
    else :
        doflatfield = True
   
    flatname = "flat_%s.fits" % k

    dirflatlist = []
    toflattenlist = []
    objectlist = []
 
    if doflatfield : 
       if not os.path.exists(flatname) :
           noflatfound = True
           print("Flat %s does not exist.  Will make one." % flatname)
           print("  ")
   
       else : 
           noflatfound = False
           print("Flat %s found already made, will use it." % flatname)
    else :
       print("Skipping the flatfield for this setup (%s)." % (k))
       noflatfound = True  # need to initialize this.

    for o in directsetupdict[k] :    
        o.set_reduced_name(prefix)
        print "%17s %15s " % (o.reducedname,o.title),
        print "%4s " % o.roi,
        # slit and disperser are key for spectra, but only 
        # a sanity check here.
        if o.slit[0].upper() == 'OPEN' :
            print "    open     ",
        else :
            print "%4s %7s " % (o.slit[0],o.slit[1]),
        print " %14s " % (o.disperser),
        print " %7s %7s " % (o.filter1id, o.filter2id)

        if doflatfield :
            if o in all_dirflats : 
               dirflatlist.append(o.reducedname)
            elif o in all_objectexps :
               toflattenlist.append(o.reducedname)

        if o in all_objectexps :
           objectlist.append(o.reducedname)
           allobjdict[o.num] = o   # have to do this here because 
                                   # o.num is not set earlier.

        # And here, finally, grab the raw image, bias it,
        # and save it in its reduced form.

        if not args.listonly : 
            osb.biasquads(o.fname,o.reducedname + ".fits")
   
    if doflatfield : 
       print "dirflats:",dirflatlist

    # save object image roots to a file
    objlistname = "obj_%s" % (k)
    osf.list_to_file(objectlist,objlistname)
 
    if doflatfield and noflatfound and (not args.listonly):
        print("Making flat for %s" % k)
        osf.make_direct_flat(dirflatlist, k) 

    if doflatfield and (not args.listonly): 
        print("Flatfielding data for %s" % k)
        for imname in toflattenlist : 
            osf.osflatten(imname + ".fits",flatname) 

    # Finally, optionally try for astrometric solutions.

    if args.wcsmatch :
        try :
            os.system("makeosmosmatch.py %s" % (objlistname))
        except :
            print("Astrometric solution attempt failed, probably because")
            print("it isn't installed or something.")
    
if args.listonly:  # convenient summary at the end for setting up.

   print(" ")
   print(" ******************  SUMMARY: *****************")
   print(" ")
   print("Reduction will include these subdirectories:") 
   print("  ")
   for d in included_dirs :
       print d
   print("  ")

   print("Here are the slit/disperser/region combinations and what")
   print("actions are anticipated for them:") 
   print("  ")
   if len(setups_to_omit) > 0 :
      print("  *** these are to be skipped ***")
      for k in setups_to_omit : 
         print("%s" % k)
      print("  ")
   print(" *** these are to be reduced. ***")
   print("  ")
   for k in todokeys :
      print("%s" % k)
   print("  ")
   print("If you want to skip any of those setups, list them in")
   print("'osmosspecred.config' with the OMITSETUP keyword.")
   print(" ")
   print("e.g. 'OMITSETUP | 1.4_outer_Red_Grism4x1B'")
   print(" ")

   # write out a file in the format I use for my archive list.
   
   keyfilename = "DirKey%d_%d" % (dirnums[0],dirnums[-1])
   keyfile = open("%s" % (keyfilename), "w")
   keez = allobjdict.keys()
   keez.sort()
   for k in keez :
       o = allobjdict[k] 
       outline = "%s\t%s\t%4d\t%13.5f\t " % (o.reducedname, o.reducedname, o.num, o.jd)
       coostring = o.telescope_cel.summarystring(delin=':',radigits=1, include_eq=1) 
       outline = outline + coostring
       outline = outline + " %5.0f  %s_%s %s" % (o.exptime,o.filter1id,o.filter2id,o.title)
       keyfile.write("%s\n" % outline)
   keyfile.close()

   print("Listed exposures in archive form in file %s." % (keyfilename))
