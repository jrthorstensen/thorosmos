#! /usr/bin/env python
"""oswave.py  --
 
    [Note: Setup requires fiducial wavelength calbration file[s], and
     a file called "osmosspecred.config" giving some fixed parameters.]

    Apply a wavelength solution to a single OSMOS spectrum, and then 
    optionally measure the velocities of a range of night-sky
    features, and shift and possibly scale the applied solution
    to zero out those velocities to the extent possible.  This is
    a single-spectrum version of the still more elaborate 
    task 'ossetwavelength.py' which is designed for batch processing.

    This is needed for any precise work because spectra taken with 
    OSMOS suffer from both shifts and scalings; the shifts are 
    presumably from telescope position, and limited testing suggests
    that the scaling is largely a function of focus of the OSMOS
    spectrograph camera (the 5000+ number) and the bench temperature.
    By contrast, the wavelength changes in modspec are well-modeled 
    by linear shifts.

    The input spectrum is assumed to be an iraf 'multispec' format,
    with the night-sky spectrum in band 3 (= 2 when zero-indexed),
    as is standard.  

    The fiducial, or reference calibration, must exist in the 
    directory AND there must be a corresponding wavelength solution
    in the database directory immediately below; if the fiducial
    spectrum is, e.g. "blue_calib.0001.fits", then there must be a 
    file called "database/idblue_calib.0001".  The calling task
    may have some naming conventions for these to allow easy 
    switching between setups.

    The strategy is as follows: 
 
    - make two clean copies of the .ms spectrum, "tempspec" and 
      "tempspec2"
    - use iraf's noao/imred/specred tasks 'refspec' and 'dispcor' 
      to set the wavelength scale of "tempspec"  WITHOUT linearing 
      the dispersion.  This simply writes the coefficients into the 
      header.
    - Measure the apparent radial velocities of a set of night 
      sky features using my convolution radial velocity software
      'convel', and convert these to wavelength shifts.
    - From these velocities, measure a shift and scale factor. 
      Optionally present a graph to the user (recommended).
    - Make a copy of the fiducial calibration's 'id...' file, 
      in which the coefficients giving the shift and scale have 
      been tweaked a bit to bring the night-sky features into line.
    - Using refespec to point the clean copy of the input spectrum 
      to the tweaked wavelength calibration, and then dispcor to
      rebin this onto a uniform wavelength grid.
    - Go back and measure the night-sky lines in the final spectrum,
      and optionally plot for the user - again, recommended.

"""

import sys
from pyraf import iraf
import gc 

# some of these iraf dependencies will go away, but not all.

from iraf import images,imcopy,imdelete,hedit # imrename
# from iraf import astutil,asthedit
# from iraf import noao,imred,bias,linebias
#from iraf import specred,apall,splot,refspectra,dispcor,specshift
from iraf import noao,imred,specred,refspectra,dispcor,splot

import astropy.io.fits as fits
import astropy.units as u

from astropy.coordinates import SkyCoord
import thorsky.thorskyutil as tsu
import thorsky.thorskyclasses3 as tsc3

import numpy as np
import matplotlib.pyplot as plt

import convel as cv

import osmosexposure as osexp

import os

def get_config() : 
    try : 
        inf = open("osmosspecred.config","r") 
    except :
        print "You need a file called 'osmosspecred.config'."
        print "This must have these defined (with examples here):"
        print "PREFIX | kf    # two-letter prefix for reduced"
        print "RAWPARENT | /home/thorsten/iraf/dec18/osmosraw "
        print ".... exiting."
        sys.exit()

    prefix = None   #initialize to allow leaving them out
    rawdir = None
    setups_to_omit = []
    noflatfield = []   # setups which you won't bother to flatfield
    displine = {}   # dispersion line for finding spec (usually the col
                     # containing H-alpha, keyed to spectral setup.
    wavecal = {}    # name of wavecal spectrum, keyed to setup.  These must
                    # already have had ident run and have excellent solutions.
    w1 =      {}    # wavelength binning parameters, also keyed to setup. 
    dw =      {}
    nw =      {}
    lowpixblue = {} # direction for night-sky shifting of spec.

    for l in inf : 
        if l[0] != '#' :
            x = l.split('|')
            if x[0].upper().find('PREFIX') > -1 : 
                if x[1].find("#") :
                    y = x[1].split('#')
                    prefix = y[0].strip()
                else : 
                    prefix = x[1].strip()
            if x[0].upper().find('RAWPARENT') > -1 :
                if x[1].find('#') :
                    y = x[1].split('#')
                    rawdir = y[0].strip()
                else : 
                    rawdir = x[1].strip()

            if x[0].upper().find('OMITSETUP') > -1 :
                if x[1].find('#') :
                    y = x[1].split('#')
                    setups_to_omit.append(y[0].strip())
                else : 
                    setups_to_omit.append(x[1].strip())

            if x[0].upper().find('NOFLATFIELD') > -1 :
                if x[1].find('#') :
                    y = x[1].split('#')
                    noflatfield.append(y[0].strip())
                else : 
                    noflatfield.append(x[1].strip())

            if x[0].upper().find('DISPLINE') > -1 :
                displine[x[1].strip()] = int(x[2])

            if x[0].upper().find('WAVECAL') > -1 :                
                wavecal[x[1].strip()] = x[2].strip()

            if x[0].upper().find('W1') > -1 :                
                w1[x[1].strip()] = float(x[2])

            if x[0].upper().find('DW') > -1 :                
                dw[x[1].strip()] = float(x[2])

            if x[0].upper().find('NW') > -1 :                
                nw[x[1].strip()] = int(x[2])

            if x[0].upper().find('LOWPIXBLUE') > -1 :  # 1 = low pixels are blue end
                lowpixblue[x[1].strip()] = int(x[2])           # -1 = low pixels are red end

    return (prefix, rawdir, setups_to_omit, noflatfield, 
             displine, wavecal, w1, dw, nw, lowpixblue)

prefix, rawdir, setups_to_omit, noflatfield, displine, wavecal, \
   w1, dw, nw, lowpixblue = get_config()

w2 = "INDEF"  # always want a fixed number of pixels in the output spectrum.

#########################################################################

# Material copied from prototype function 'adjust_to_ns.py'

# This routine copies the master comp's database/id file -- where
# IRAF stores wavelength solutions -- but in so doing it tweaks two
# of the parameters that shift and scale the legendre poly solution.
# Tests give hope that this can remove both a zeropoint shift and 
# a linear 'stretch'.

# this does double-duty as a thing to read the central wavelength
# and range from the coefficients in an existing refcomp; just 
# specify fakenameroot = None to get those handed back.

def tweak_dispersion(refcomp, ctrshift = 0., scalefac = 1.,
       fakenameroot = "fakedbluecomp") :

    if fakenameroot == None : write_output = False
    else : write_output = True

    # copy the dispersion solution and tweak a couple of 
    # parameters.

    refdispfile = open("database/id" + refcomp,"r")
    if write_output: 
        outf = open("database/id%s" % (fakenameroot),"w")
        print "opened database/id%s" % (fakenameroot)
    linenum = 0
    coefficients_found = False 
    coeffs = []  # hand them all back in case more elaborate measures needed
    for l in refdispfile : 
        # print l
        # line numbers are easy way to keep track of header
        # not sure it's necessary to fake this
        linenum = linenum + 1
        if linenum == 2 and write_output: 
            outf.write("begin\tidentify\t%s - Ap 1\n" % (fakenameroot))
        elif linenum == 3 and write_output:
            outf.write("\t  id  %s  TAG \n" % (fakenameroot))
        elif linenum == 4 and write_output: 
            outf.write("\t  %s - Ap 1\n" % (fakenameroot));
        elif not coefficients_found : 
            if write_output : outf.write(l)
        else :  # we're in the coefficients, which is the business end
            coeff_num = coeff_num + 1
            # print "coeff_num = ", coeff_num, "l = ", l,"len(l) = ",len(l)
            # blank lines cause problems, so append conditionally
            if len(l) > 1 and l[0] != '#': coeffs.append(float(l.strip()))
            if coeff_num == 5 :
                dispcenter = float(l.strip())
                print "dispcenter ",dispcenter
                if write_output : outf.write("\t\t%17f\n" % (dispcenter + ctrshift))   
                print "wrote dispcenter + ctrshift = ",dispcenter + ctrshift
            elif coeff_num == 6 :
                window = float(l.strip())
                print "window ",window
                if write_output : outf.write("\t\t%17f\n" % (window * scalefac))    # also a test
                print "write window * scalefac ",window * scalefac
            else : 
                if write_output : outf.write(l)
            if l[0] == "#" : # there is a line at the top of each solution with a timestamp 
                # --- if encountered here, it means that ...
                # oops, there's another solution appended to the id file.  Scratch and start over.
                coefficients_found = False
                coeffs = []
                coeff_num = 0
        if l.find('coefficients') > -1 :
            coefficients_found = True
            coeff_num = 0

    refdispfile.close() 
    if write_output : outf.close() 
    if not write_output : return dispcenter, window, coeffs

#####################################################################

def robust_straightline(xtofit, ytofit, errs, maxresid = 0.3) :   

    # Fits a straight line, and iterates if outliers bigger than 
    # maxresid. Used for non-interactive fit of the delta-wavelengths 
    # of the night sky spectrum.

    maxerr = 1e6  # to start the loop.

    # We'll be deleting points from the array, so make copies to avoid
    # corrupting the originals.

    xarr = xtofit[:]
    yarr = ytofit[:]   
    wgtarr = []
    for e in errs : 
       # weights, with a very rough normalization factor thrown in.
       wgtarr.append(100. / (e * e))
    # print xarr,yarr,wgtarr
    xdeleted = []
    ydeleted = []

    iteration = 0
    while(maxerr > 0.5 and iteration < 4) :  # hard number ok since we have a particular setup
        iteration = iteration + 1
        residsq = []
#        print "iteration %d len(xarr) = %d" % (iter,len(xarr))
        if len(xarr) > 2 :  # stop if you've thrown too much away
            fitcoefs = np.polyfit(xarr, yarr,1,w = wgtarr) 
            maxerr = 0.
            for x in xarr :  
                ind = xarr.index(x)
                y = yarr[ind]
                resid = abs(y - np.polyval(fitcoefs,x))
                residsq.append(resid * resid)
#                print "ind %d x %f y %f resid %f" % (ind,x,y,resid)
                if resid > maxresid and len(xarr) > 3 :
                    xdeleted.append(xarr[ind])
                    ydeleted.append(yarr[ind])
                    del xarr[ind]
                    del yarr[ind]
                    del wgtarr[ind]
                if resid > maxerr : 
                    maxerr = resid

            residsqarr = np.array(residsq) 
            meansq = np.sum(residsqarr) / residsqarr.shape[0]
            rms = np.sqrt(meansq)
#            print("iteration %d: %d points, rms = %f" % (iteration, len(residsq), rms))
           
   
    # return number of points used, which can be used as a quality screen.

    return (fitcoefs, len(xarr), xdeleted, ydeleted, rms)

################################################

# this "onpress" is for passing key-based commands back from a
# matplotlib plot.  For reasons I don't completely understand this 
# has to be mutable object -- I tried using a list, which should
# mutable, but it didn't work right away.  The example cited below
# uses a dictionary, which apparently does work.

# I have not tested this business of rejecting N/S fits very extensively.
# In practice, it's generally better than nothing in any case.

acceptfit = {}  # this is mutable ... 

# See: 
# https://stackoverflow.com/questions/15032638/how-to-return-a-value-from-button-press-event-matplotlib

# 'onpress' is later linked to key press events.

def onpress(event) :  # for use in reviewing solutions.
    # print "event.key = ",event.key
    if event.key.upper() == 'Q' :
        #print "Got 'Q'"
        plt.close('all') 
        print "Closed."
    if event.key.upper() == 'X' or event.key.upper() == 'D' or event.key.upper() == 'R' :
        # print "event.key = ",event.key
        acceptfit['key'] = event.key
        # print "acceptfit = ",acceptfit
    
################################################

# NIGHT-SKY AND COMPARISON CALIBRATION LINES

# I'm setting them as a dictionary keyed by the slit so as to
# be able to use the same procedure in different setups.

# More properly these should include the disperser information,
# but the inner slit is used almost always with the blue grism, 
# the outer with the red, and the center not much.

# The night-sky wavelengths are from Osterbrock et al's 1996
# PASP paper on the night-sky spectrum from the Keck high resolution 
# spectrograph.

# The linelist for the "center" slit is a guess -- I haven't taken 
# any data in the 
# center slit for some time.  I think it's usually used with the red
# grism in which case the 'outer' set - designed for red grism + outer --
# may be a better starting point.  The list here assumes the blue grism
# plus center slit, which covers only one strong N/S feature, 5577.

nswavdict = { 'inner' : [5577.338,5915.301,5932.862,5953.420,5977.1,
                6170.638,6257.961,6287.434,6300.304,
                6498.729, 6533.044, 6577.2],
              'center' : [5577.338],  
              'outer' : [5577.338, 6300.304, 6863.96, 7276.41, 7340.89,
                7524.1, 7794.11, 7964.65, 8344.602, 8399.17, 8430.17, 8827.096]}

# Here are wavelengths from HgNe for 'inner' with blue grism, 
# 'outer' with red grism, and 'center' with blue grism -- which should
# probably be the red grism since center slit is seldom used with the 
# blue grism.
 
hgnedict = { 'inner' : [4046.530, 4358.343, 5460.74, 5769.598, 5790.659,
               5852.488, 5944.834, 5975.535, 6029.997, 6074.338,
               6096.163, 6143.063, 6217.281, 6266.495, 6334.428,
               6402.246, 6506.528, 6532.882, 6598.953 , 6678.277,
               6717.048], 
               'center' : [4046.530, 4358.343, 5460.74, 5769.598, 5790.659,
               5852.488], 
               'outer' : [5460.74, 5769.598, 5790.659,
               5852.488, 5944.834, 5975.535, 6029.997, 6074.338,
               6096.163, 6143.063, 6217.281, 6266.495, 6334.428,
               6402.246, 6506.528, 6532.882, 6598.953 , 6678.277,
               6717.048, 6929.468, 7173.939, 7245.1670, 
               7438.8990, 7488.871, 8082.458, 8136.405, 8300.326, 
               8377.608, 8495.360, 8591.258, 8634.647, 8654.383, 
               8919.501, 8418.427, 8377.608]}
               # 8853.867, 8919.501, 8418.427, 8377.608]}

#################################################################


def setwav(inputspec, calibspec, setup, do_nscorr = True, review = True) :

# NIGHT-SKY AND COMPARISON CALIBRATION LINES

# I'm setting them as a dictionary keyed by the slit so as to
# be able to use the same procedure in different setups.

# More properly these should include the disperser information,
# but the inner slit is used almost always with the blue grism, 
# the outer with the red, and the center not much.

# The night-sky wavelengths are from Osterbrock et al's 1996
# PASP paper on the night-sky spectrum from the Keck high resolution 
# spectrograph.

# The linelist for the "center" slit is a guess -- I haven't taken 
# any data in the 
# center slit for some time.  I think it's usually used with the red
# grism in which case the 'outer' set - designed for red grism + outer --
# may be a better starting point.  The list here assumes the blue grism
# plus center slit, which covers only one strong N/S feature, 5577.

    nswavdict = { 'inner' : [5577.338,5915.301,5932.862,5953.420,5977.1,
                6170.638,6257.961,6287.434,6300.304,
                6498.729, 6533.044, 6577.2],
              'center' : [5577.338],  
              'outer' : [5577.338, 6300.304, 6863.96, 7276.41, 7340.89,
                7524.1, 7794.11, 7964.65, 8344.602, 8399.17, 8430.17, 8827.096]}

    thisw1 = w1[setup]
    thisdw = dw[setup]
    thisnw = nw[setup]

    lightsp = 299792.458

    # Get the central wavelength, spectrum span from the 
    # fiducial calibration spectrum (and the rest of the coeffs also).  
    # Giving 'None' for fakenameroot
    # makes this just read and report without tweaking anything.
       
    (referencewav, referencespan, referencecoeffs) = \
            tweak_dispersion(calibspec, fakenameroot = None) 

    print "The fiducial calibration derived from %s has:" % (calibspec)
    print "cen, win", referencewav, referencespan
    # print "referencecoeffs = ",referencecoeffs
       

    if setup.lower().find('inner') > -1 :
        nswavelengths = nswavdict['inner']
        fakenameroot = "fakedbluecomp"
    elif setup.lower().find('outer') > -1 : 
        nswavelengths = nswavdict['outer']
        fakenameroot = "fakedredcomp"
    elif setup.lower().find('center') and k.lower().find('blue') : 
        nswavelengths = nswavdict['centr']
        fakenameroot = "fakedcentercomp"
    elif setup.lower().find('center') and k.lower().find('red') : 
        nswavelengths = nswavdict['outer']
        fakenameroot = "fakedredcomp"

    inroot = inputspec.strip()
    inroot = inputspec.replace(".fits","")
    inroot = inputspec.replace(".ms","")

    dispname = "d%s.fits" % (inroot)
    comstr = "/bin/rm %s" % (dispname)   # kill for redos.
    os.system(comstr)
    os.system("/bin/rm tempspec.fits")  
    os.system("/bin/rm tempspec2.fits")   

    # time and the sky info has already been inserted, but want to
    # grab some header info for plot labels.

    hdu = fits.open(inroot + ".fits") 
    hdr = hdu[0].header
    objname = hdr['object']  
    exptime = hdr['exptime'] 
    twilight = hdr['twilight'] 
    hdu.close()

    imcopy(inroot + ".ms","tempspec2")   # make a copy with no wave cal info 
                                         # so you can install pristinely later

        
    
    # we want to refer the spectrum to the reference calib whether we're 
    # night-sky correcting or not.

    # Note that to install a wavelength calib, you need to copy the calib spec into your
    # quick-look directory, AND create a directory "database" into which you
    # stick the "idxxxx" file, where xxxx is the image name of the calib spec.

    refspectra(inroot + ".ms", references = calibspec,
       ignoreaps = "yes", sort = "", group = "", time = "no",
       override = "yes", confirm = "no", assign = "yes", verbose = "yes")

    if do_nscorr : 

        # the first step in n/s correction is to create a temporary copy 
        # that has the fiducial coeffs in the header so it knows about 
        # wavelengths:
    
        dispcor(inroot + ".ms","tempspec",linearize="no",
             database = "database", w1 = "INDEF", w2 = "INDEF",
             dw = "INDEF", nw = "INDEF", confirm = "no", ignoreaps = "yes",
                listonly = "no", verbose = "yes")
   
        # Measure the wavelengths of the night sky lines in the dispcor'd
        # (but not rebinned!) spectrum.
            
        deltawavs = {}   # dictionary of wavelength shifts keyed to rest wavelength
        waverrs = {}        # rough estimated error by wavelength
        delta_5577 = 1000.  # keep these out separately to use in constant offset.
        delta_6300 = 1000.  # shifts, which are a little better than nothing.
    
    
        for n in nswavelengths :
    
        # The object data are all IRAF multispecs; the object is in 'band 1' which is
        # index zero, the sky in 'band 3' which is index 2 in the zero-indexed data array.
        # Note that helio correction is not applied, and  shouldn't be.  
        # Note also that setting the "raw_error" flag does a crude
        # estimate of the velocity uncertainty by assuming the sky spectrum follows
        # poisson statistics with a gain of 1; background is modeled as a running
        # median.  This is not accurate, but should be reasonable for fit weighting.
                   
        #    (vel,err) = cv.specvel("tempdisp.fits",2,n,half_wid = 6., linwid=7.,

        # half_wid, linwid etc tuned a bit empirically but should perhaps be
        # made adaptive.

            (vel,err) = cv.specvel("tempspec.fits",2,n,half_wid = 5., linwid=5.,
              search_wid=20., rootsearch = True, do_error = False, raw_error = True, helio_correct = False)
    #                   print("wav %f : vel %f, err %f" % (n,vel,err))
    
        # convert the velocity to a wavelength shift.
    
            delta = (vel / lightsp) * n
            waverr = err * n / lightsp
                   
            if abs(n - 5577.3) < 1. : delta_5577 = delta  # save this to revert to simple shift.
            if abs(n - 6300.3) < 1. : delta_6300 = delta  
                       
            # censor out velocities with large estimated errors, which I'll set as 30
            # km/s based on some experimentation.
    
            if abs(err) < 30. and abs(waverr) > 0. :  # also avoid zero errs (returned when 
                                                       # specvel goes haywire, apparently). 
                deltawavs[n] = delta
                waverrs[n] = waverr
                   
             # stack the results in lists ordered by wavelength.
             # This may be overly complicated by it doesn't matter much.
    
        restwavs = deltawavs.keys()
        restwavs.sort()
        shiftarr = []
        error_arr = []
                   
        for r in restwavs :
             shiftarr.append(deltawavs[r])
             error_arr.append(waverrs[r])
               
               # optionally view result.

        if review :

            fig = plt.figure()
            cid = fig.canvas.mpl_connect('key_press_event',onpress)

            plt.plot(restwavs, shiftarr,'bo')
            plt.errorbar(restwavs,shiftarr,error_arr,fmt='o')

            shiftarr_uncorr = shiftarr
            restwavs_orig = restwavs

            # Fit a robust straight line, iteratively excluding residuals too large.

        if len(restwavs) > 2 : 
            # print "restwavs ",restwavs
            # print "shiftarr ",shiftarr
            # print "error_arr",error_arr

            # again, maxresid = 0.2 seems OK empirically.

            (shiftmodel, nkept, xdeleted, ydeleted,rms) = robust_straightline(restwavs,
                             shiftarr,error_arr,maxresid=0.2)

            if review :  # optionally review

                # overstrike deleted points
                plt.plot(xdeleted,ydeleted,'x',markersize=15)

                # plot the fitted straight line
                y1 = np.polyval(shiftmodel, restwavs[0])
                y2 = np.polyval(shiftmodel, restwavs[-1])
                plt.plot([restwavs[0],restwavs[-1]],[y1,y2],'-')
   
            # print "shiftmodel:",  shiftmodel
                   
            # shiftmodel[1] is the y-intercept at wavelength zero and 
            # shiftmodel[0] is the slope.  Find the shift at the middle of 
            # the spectrum from this, and also the scale factor to apply to 
            # the results.
            shift_at_midwav = shiftmodel[0] * referencewav + shiftmodel[1]
            scalefac = 1.00 - shiftmodel[0]
            print "kept ",nkept," pts, shift at mid:", shift_at_midwav," scalefac: ",scalefac
   
        else :
            nkept = len(restwavs)
            print "Too few line centers survive for a fit."

        # Revert if the fit isn't much good
        # Save a note for the header of output.

        if nkept < 3 or rms > 0.35 :  
            if delta_5577 < 999. : 
                shift_at_midwav = delta_5577
                scalefac = 1.00
                print "POOR FIT, doing a simple 5577 shift with no stretch."
                correction_text = "Wavelengths shifted %5.3 A using 5577"
            else : 
                shift_at_midwav = 0.
                scalefac = 1.00
                print "POOR FIT and 5577 no good, so no correction."
                correction_text = "Could not apply night sky correction"

        else :
            correction_text = "night sky zpt: %6.3f A, scalefac: %8.6f, %d pts" % \
                      (shift_at_midwav, scalefac, nkept)



        if review : 
            plt.title("%s - %s - %5.0f s - %4.1f mag" % (inroot,objname,exptime,twilight))
            plt.xlabel("Wavelength")
            plt.ylabel(r"$\Delta \lambda$")
            plt.ion()
            plt.show()
               
        print "tweaking with scalefac = %8.6f, shift %f" % (scalefac,shift_at_midwav)

        tweak_dispersion(calibspec,ctrshift = -1. * shift_at_midwav, 
                scalefac = scalefac, fakenameroot = fakenameroot)
              
        # this REALLY needs 'add = "yes"' or dispcor fails horribly after a few spectra.
        hedit("tempspec2","refspec1",fakenameroot,add="yes",update="yes",verify="no")
        # at this point add in a note about the n/s correction, too.
        hedit("tempspec2","nscorr",correction_text,add="yes",update="yes",verify="no")
              
        # Finally, apply the tweaked wavelength calibration and bin the spectrum.
              
        dispcor("tempspec2", dispname, linearize = 'yes', w1 = thisw1, dw = thisdw, 
               nw = thisnw, w2 = "INDEF", listonly='no',verbose='yes', ignoreaps = 'yes')

        # for quality check, measure the lines again and optionally plot.
              
        deltawavs = {}   # dictionary by rest wavelength
        errors = {}
              
        for n in nswavelengths :
             # band numbers are zero indexed so spec is zero, sky is 2.
              
             (vel,err) = cv.specvel(dispname,2,n,half_wid = 6., search_wid=3., 
                        do_error = False, raw_error = True, helio_correct = False)
              
             # get the wavelength shift from the velocity.
             delta = (vel / lightsp) * n
             deltawavs[n] = delta
             errors[n] = err * n / lightsp
              
              # stack the results in ordered lists, again may be overly elaborate.
              
        restwavs = deltawavs.keys()
        restwavs.sort()
        shiftarr = []
        error_arr = []
              
        for r in restwavs :
            shiftarr.append(deltawavs[r])
            error_arr.append(errors[r])
              
              #print "shiftarr:",shiftarr
              #print "error_arr",error_arr
              #print "len(shiftarr), len(error_arr)",len(shiftarr), len(error_arr)
              #print "len(restwavs) = ",len(restwavs)
              
              # optionally view result -- used this to tweak convel parameters.
              
        if review : 
   
            acceptfit['key'] = 'A'  # default is to accept result.
                  
            fig = plt.figure()
            cid = fig.canvas.mpl_connect('key_press_event',onpress)
            plt.plot(restwavs, shiftarr,'bo')
            plt.errorbar(restwavs, shiftarr, error_arr,fmt='o')
            plt.plot(restwavs_orig, shiftarr_uncorr,'rs')
            plt.title("%s - %s - %5.0f s - %4.1f mag" % (dispname,objname,exptime,twilight))
            plt.xlabel("Wavelength")
            plt.ylabel(r"$\Delta \lambda$")
            plt.ion()
            plt.show()
   
                  
            # print("acceptfit['key'] = ",acceptfit['key'])
            if acceptfit['key'].upper() == 'X' or \
               acceptfit['key'].upper() == 'R' or \
               acceptfit['key'].upper() == 'D' :
               imdelete(dispname + ".fits") 
    
    else :  # if do_nscorr is false, just do the rebinning.  This is a lot simpler!

        dispcor(inroot + ".ms", dispname, linearize = 'yes', w1 = thisw1, dw = thisdw, 
               nw = thisnw, w2 = "INDEF", listonly='no',verbose='yes', ignoreaps = 'yes')

if __name__ == "__main__" : 
      
       print wavecal 
