#!/usr/bin/env python
"""osflatfield.py -- routines for flatfielding osmos data, 
    and for constructing flatfields, both spectro and 
    direct.
"""

import numpy as np
from astropy.io import fits
from pyraf import iraf
from iraf import images, immatch, imcombine   # it's just easier.
from iraf import noao, imred, specred, response
from iraf import imstatistics
import os

from matplotlib import pyplot as plt

def osflatten(objimage, flatimage) :  
    
    hduobj = fits.open(objimage, mode = "update")
    arrobj = hduobj[0].data
    arrhead = hduobj[0].header

    hduflat = fits.open(flatimage) 
    arrflat = hduflat[0].data

    if arrobj.shape != arrflat.shape : 
        print("object image is ",arrobj.shape, "flatfield is ",arrflat.shape,
               "... exiting osflatten.")
        return(-1)

    hduobj[0].data  = arrobj / arrflat
    arrhead['COMMENT'] = "Divided by flatfield %s" % (flatimage)

    hduobj.flush()
    hduobj.close()
    hduflat.close()

    return(0) # success

def list_to_file(inlist, listfname) : 
    # for the IRAF "@list" mechanism
    outf = open(listfname,"w")
    for l in inlist : 
        if len(l) > 0 : 
            outf.write("%s\n" % (l))
    outf.close()
    
def make_spec_flat(misflatlist, skyflatlist, slitdisperser) : 
    
    flatlistname = "flatlist_%s" % slitdisperser
    if len(misflatlist) > 0 : 
        list_to_file(misflatlist, flatlistname) 
    else :
        print("zero-length MIS flat list, so can't make flat.")
        return(-1)

    imcombine.combine = "median"
    imcombine.reject = "none"
    imcombine.outtype = "real"
    imcombine.offsets = "none"
    imcombine.scale = "mean"   # may not be needed for MIS flats
    imcombine.zero = "none"
    imcombine.weight = "none"
    
    outflatname = "flat_%s" % (slitdisperser)
    imcombine("@" + flatlistname, outflatname)

    # If slit balance flats (twilight exposures) were taken 
    # with this setup, correct the flatfield -- this is desireable
    # because ever since the MIS flatfield mirror was replaced by
    # the retrocam prism, the MIS flatfield lamp illuminates the 
    # slit very non-uniformly.  A spectrum of the bright twilight
    # sky gives a reading of the actual throughput of the slit
    # across the field.
    
    if len(skyflatlist) > 0 :
        skyflatlistname = "sky" + flatlistname
        list_to_file(skyflatlist, skyflatlistname) 
        imcombine("@" + skyflatlistname, "skyflat_%s" % (slitdisperser))
    
        hdusky = fits.open('skyflat_%s' % slitdisperser + '.fits')
        skyarr = hdusky[0].data
        # shape = skyarr.shape
        # print skyarr.shape

        hduflat = fits.open(outflatname + ".fits", mode = "update")
        flatarr = hduflat[0].data

        flatonsky = flatarr / skyarr # this is the illumination of the MIS
    
        # collapse along dispersion direction, leaving out extreme ends 
        flatonskysum = np.sum(flatonsky[:,100:flatonsky.shape[1]-100],axis=1)
        # fit it with a polynomial, ignoring edges
        fakeaxis = np.arange(0,flatonskysum.shape[0],1.)
        p = np.polyfit(fakeaxis[10:fakeaxis.shape[0]-10],flatonskysum[10:fakeaxis.shape[0]-10],4)  
        # generate a curve fitted to the dispersion-summed ratio
        fittedcurve = np.polyval(p,fakeaxis)

        # turn it into a column vector
        fittedy = np.vstack(fittedcurve)
        # divide it into the MIS flatfield image
        flatarr = flatarr / fittedy  
        # put out the sky-balance corrected MIS flat.
        hduflat[0].data = flatarr
        hduflat.flush()
        hduflat.close()
        hdusky.close()

    # Use noao 'response' to normalize this.
    print("Starting response.")
    specred.dispaxis = 1
    response.function = "spline3"
    response.order = 10
    response.low_reject = 2
    response.high_reject = 2
    response.niterate = 3
    response.interactive = "yes"
    
    response(outflatname, outflatname, "norm" + outflatname)
    print("Made flatfield %s." % ("norm" + outflatname))

def make_direct_flat(dirflatlist, dirsetup) :
  # make a direct flat from a list of image name roots that have
  # already been verified to be in the same filter and readout format.
  # This is a lot simpler than making a spectroscopic flat.
        
    flatlistname = "flatlist_%s" % dirsetup
    if len(dirflatlist) > 0 : 
        list_to_file(dirflatlist, flatlistname) 
    else :
        print("zero-length flat list, so can't make flat.")
        return(-1)

    imcombine.combine = "median"
    imcombine.reject = "none"
    imcombine.outtype = "real"
    imcombine.offsets = "none"
    imcombine.scale = "mean"   
    imcombine.zero = "none"
    imcombine.weight = "none"
    
    outflatname = "flat_%s.fits" % (dirsetup)
    imcombine("@" + flatlistname, outflatname)

    # normalize this to its own median using astropy and 
    # numpy tools.

    hduflat = fits.open(outflatname, mode="update", ignore_missing_end = True)
    hdrflat = hduflat[0].header
    arr = hduflat[0].data
    ny, nx = arr.shape
    # ignore edges in computing normalization factor.
    normfac = np.median(arr[40:ny-40,40:nx-40]) 
    hduflat[0].data = arr / normfac
    hduflat.flush()
    hduflat.close()

