#!/usr/bin/env python
"""osmosspecreduct_astropy.py [--listonly --firstdate 181213 --lastdate 181219]
     task to parse and process osmos raw data.
   -- 2019 July - remove cooclasses dependence with astropy.
   -- built on osmosinventory code.
   -- edit "osmosspecred.config" in same directory before using.
   -- the individual nightly directories should have integer names,
      eg 181213 (yymmdd usually).
   -- You can optionally specify a range of dates; firstdate and lastdate
       default to 0 and 9999999 so the default includes all subdirectories.
   -- WHAT IT DOES:
      -- Parses the data out into direct images (no disperser and 
            no slit) and spectra (disperser and slit); throws away
            slit + no disperser slit location images, and any images 
            with 'focus' in the title.
      -- for direct images, makes lists of object data, and data 
      -- makes lists of spectral images, by slit/disperser combination,
            and so on.
"""

import sys
from pyraf import iraf
from iraf import hselect  # leave this for now since it works
# from cooclasses import *
import glob
import osbias as osb
import osflatfield as osf
import os
from copy import deepcopy

import numpy as np

# import fitmatchradec as fmrad
# I'm going to replace the fitmatchradec stuff with python wcs tools.

import thorsky.thorskyutil as tsu
import thorsky.thorskyclasses3 as tsc3
import astropy.coordinates as coo
import astropy.units as u
from astropy.wcs import WCS
from astropy.wcs.utils import pixel_to_skycoord
from astropy.time import Time
import astropy.io.fits as fits

import argparse

parser = argparse.ArgumentParser(description="bias and flatfield OSMOS raw data.")
parser.add_argument("--firstdate",help="first subdir. to parse, eg 121813",type=int,default=0)
parser.add_argument("--lastdate",help="last subdir. to parse, eg 121817",type=int,default=9999999)
parser.add_argument("--listonly",help="List without computing",action="store_true")

args = parser.parse_args()

################################################################

# The inner and outer slits are almost 6 arcmin from the 
# telescope axis.  Header coords are those of the telescope axis.
# This bit of code infers the RA and dec of the target from the
# slit identification, the telscope coordinates, and the rotator 
# angle.

class rotatedobs :

   def __init__(self,telaxiscel,rotangle,targcel = None,time=Time('2020-01-01T00:00:00Z'),slit=1):

      # time is roughly now but need not be accurate to better than a couple years!

      self.targcel = targcel   # defaults to None -- now a SkyCoord
      self.telaxiscel = telaxiscel # also a SkyCoord
      self.rot = coo.Angle(rotangle,unit='deg')  # convert to an Angle

      # self.telaxiscel.selfprecess(2019.)
      self.currentfr = tsu.currentFK5frame(time)  # rotator frame is always in the current epoch.
      self.telaxiscel.transform_to(self.currentfr)
      self.tanplane = self.maketanplane(self.telaxiscel)

      self.implied_obj_cel = None
      self.implied_obj_miss = None
      self.implied_obj_xieta = None   # [xi, eta] of implied position around true 
      self.slit = slit  # inner; 0 is center, -1 is outer.  
                     # inner is at x = -342, y = 0; outer at x = +345, so 
                     # it's close enough to use an integer.

   def setxieta(self):
      [xi,eta] = fmrad.tostdpy(self.targcel.ra.val,self.targcel.dec.val,
            self.telaxiscel.ra.val,self.telaxiscel.dec.val)
      self.xi = xi
      self.eta = eta   # an attempt to debug ... 

   def maketanplane(self, centercoord) :  # makes a tangent plane WCS around a SkyPosition
        # this follows procedures demonstrated in Shupe et al.'s little paper on the 
        # Palomar Transient Factory astrometry pipeline,
        # PROC. OF THE 17th PYTHON IN SCIENCE CONF. (SCIPY 2018)
        # -- basically, the xi/eta stuff is built into that package though it's a bit
        # obscure.  The idea is to create a WCS out of 'tin hair'. 
    
        w = WCS(naxis=2)
        w.wcs.crpix = [0.0,0.0]   # origin of the tangent plane in 'pixel' coords
        w.wcs.cdelt = np.array([1./3600.,1./3600.])  # coordinate units are 1 arcsecond.
        w.wcs.crval = [centercoord.ra.deg,centercoord.dec.deg]
        w.wcs.ctype = ["RA---TAN","DEC--TAN"]
        return w
    
   def guess_obj_from_tel(self) :

      # given telescope coords plus rotator, guess object coords

      # X and Y are in a system aligned with the rotator with origin on the
      # telescope axis (ideally).

      if self.slit == 1 :
          X = -342.  # inner
      elif self.slit == -1  :
          X = 345.   # outer
      else :
          X = 0.     # center, in which case this isn't needed.
      Y = 0.      # position of inner slit
#      rot = -1. * self.rotangle / cooconsts.DEG_IN_RADIAN
      # rot = self.rotangle / cooconsts.DEG_IN_RADIAN

      # rotate this into tangent plane system
      
      Xprime = np.cos(self.rot) * X + np.sin(self.rot) * Y   # no need to convert since self.rot is an Angle
      Yprime = -1. * np.sin(self.rot) * X + np.cos(self.rot) * Y

      # raobj, decobj = fmrad.greek2radec(Xprime,Yprime,self.telaxiscel.ra.val,
      #         self.telaxiscel.dec.val)
      # self.implied_obj_cel = celest([raobj,decobj,2019.])
      
      # and transform to a SkyCoord

   #   print X, Y, Xprime, Yprime
      
      self.implied_obj_cel = pixel_to_skycoord(Xprime,Yprime,self.tanplane)
      self.implied_obj_cel.transform_to("icrs")

 
############### end of target position inference code ############

#### Code to read reduction configuration from osmosspecred.config ######

def get_config() : 
    try : 
        inf = open("osmosspecred.config","r") 
    except :
        print "You need a file called 'osmosspecred.config'."
        print "This must have these defined (with examples here):"
        print "PREFIX | kf    # two-letter prefix for reduced"
        print "RAWPARENT | /home/thorsten/iraf/dec18/osmosraw "
        print ".... exiting."
        sys.exit()

    prefix = None   #initialize to allow leaving them out
    rawdir = None
    setups_to_omit = []
    noflatfield = []   # setups which you won't bother to flatfield
    displine = {}   # dispersion line for finding spec (usually the col
                     # containing H-alpha, keyed to spectral setup.
    wavecal = {}    # name of wavecal spectrum, keyed to setup.  These must
                    # already have had ident run and have excellent solutions.

    # This is a rather verbose way of parsing this but it works, and
    # it's easy to customize.

    for l in inf : 
        if l[0] != '#' :
            x = l.split('|')
            if x[0].upper().find('PREFIX') > -1 : 
                if x[1].find("#") :
                    y = x[1].split('#')
                    prefix = y[0].strip()
                else : 
                    prefix = x[1].strip()
            if x[0].upper().find('RAWPARENT') > -1 :
                if x[1].find('#') :
                    y = x[1].split('#')
                    rawdir = y[0].strip()
                else : 
                    rawdir = x[1].strip()

            if x[0].upper().find('OMITSETUP') > -1 :
                if x[1].find('#') :
                    y = x[1].split('#')
                    setups_to_omit.append(y[0].strip())
                else : 
                    setups_to_omit.append(x[1].strip())

            if x[0].upper().find('NOFLATFIELD') > -1 :
                if x[1].find('#') :
                    y = x[1].split('#')
                    noflatfield.append(y[0].strip())
                else : 
                    noflatfield.append(x[1].strip())

            if x[0].upper().find('DISPLINE') > -1 :
                displine[x[1]] = int(x[2])

            if x[0].upper().find('WAVECAL') > -1 :                
                wavecal[x[1]] = x[2]

    return (prefix, rawdir, setups_to_omit, noflatfield, displine, wavecal)

prefix, rawdir, setups_to_omit, noflatfield, displine, wavecal = get_config()

class osexposure :
   # information on a single exposure.
   def __init__(self, fname) :
      self.fname = fname
      self.localfname = os.path.split(fname)[-1]
      try :
         self.parentdir = os.path.split(fname)[-2]
      except :
         self.parentdir = None
      self.reducedname = None  # with the standard prefix (usually two letters)
      self.num = None          # sequence number (int)
      self.telescope_cel = None # telescope axis coords (from header)
      self.cel = None           # inferred coordinates of target
      self.rotangle = None
      self.title = None
      self.imagetyp = None
      self.isfocus = False
      self.exptime = None
      self.jd = None
      self.filter1 = None 
      self.filter1id = None
      self.filter2 = None 
      self.filter2id = None
      self.disperser = None
      self.slit = None 
      self.naxis1 = None
      self.naxis2 = None
      self.roi = None
      self.mirror = None 
      self.lamps = None
      self.adjacent_comps = None
      
   def printall(self) :  # mostly for diagnostics.
      print "filename: ", self.fname
      print "tel coords:",self.telescope_cel.ra.to_string(unit=u.hourangle,sep=':'),' ', \
                          self.telescope_cel.dec.to_string(unit=u.deg,sep=':')
      print "coords:",self.implied_obj_cel.ra.to_string(unit=u.hourangle,sep=':'),' ', \
                          self.implied_obj_cel.dec.to_string(unit=u.deg,sep=':')
      print "rotangle ", self.rotangle
      print "object:", self.title
      print "type  :",  self.imagetyp 
      print "exp, jd, ",self.exptime,self.jd
      print "filter1 ", self.filter1, self.filter1id 
      print "filter2 ", self.filter2, self.filter2id
      print "disperer", self.disperser
      print "slit : ", self.slit
      print "format : ", self.naxis1, " x ",self.naxis2
      print "mirror, lamps: ", self.mirror, self.lamps

   def set_reduced_name(self, prefix) :
      root = self.localfname.replace('.fits','')
      # print root
      x = root.split('.')
      # print x, x[-1]
      self.num = int(x[-1])   # this means originals must be e.g. b.0001.fits
      self.reducedname = prefix + "%04d" % (self.num)
      self.reducedname = self.reducedname.strip()

   def set_target_cel(self) :  # assumes info has been loaded.
      ro = rotatedobs(self.telescope_cel,self.rotangle)
      ro.slit = 0
      try :
           if(self.slit[1].find('nner') > -1) : 
                 ro.slit = 1
           elif(self.slit[1].find('uter') > -1) :
                 ro.slit = -1 
      except :
           pass 

      ro.guess_obj_from_tel()
      self.cel = deepcopy(ro.implied_obj_cel)  

      # this now automatically hands back a SkyCoord in ICRS.


###############

class objgrp :  # all observations of a single object, assigned by proximity

   def __init__(self, osexp) :
      self.osexps = [osexp]
      self.cel = osexp.cel
      self.titles = [osexp.title]

###############

# print "searching:", "%s/" % (rawdir)

dirlist = glob.glob('%s/*' % (rawdir))   # lists all subdirectories immediately below.

included_dirs = []  # within range of dates ...
dirnums = []        # useful later

for fullpath in dirlist :
   d = os.path.split(fullpath)[-1]
   d = d.replace("/","")
   try :
      dnum = int(d)
      if dnum > 150000 and dnum < 400000: # start of 2015 to be conservative 
         if dnum >= args.firstdate and dnum <= args.lastdate :
            included_dirs.append(fullpath)
      dirnums.append(dnum)
   except :
      pass

included_dirs.sort() 
dirnums.sort()

print "Including directories: " 
for d in included_dirs :
   print d

# Set up lists of various kinds of exposures.

all_exposures = []
all_objectexps = []
all_groups = []
all_dirflats = []
all_misflats = []
all_slitflats = []
all_comps = []
all_biases = []
all_darks = []

all_objgrps = []    # object exposure groups, assigned by proximity.

roidict = {(1088, 1024) : "1k", (4128, 1016) : "4x1k", (4128,4064) : "4k",
           (1080, 4064) : "1x4k", (2064, 508) : "4x1B"}

slitdispdict = {}   # spectral exposure dictionary keyed
allobjdict = {}     # information held for archiving, keyed by numer

#  Scan all the images in all the directories; make osexposures for each of them.

for d in included_dirs :
   print "Processing ", d
   fitsfiles = glob.glob(os.path.join(d,"*.fits"))
   fitsfiles.sort()
   for f in fitsfiles :
      hselout = hselect(f,"ra,dec,equinox,exptime,imagetyp","yes",Stdout=1)
      x = hselout[0].split('\t')
      rastr = x[0].replace('"','')  # repaired headers can have quotes in these.
      rastr = rastr.strip()
      decstr = x[1].replace('"','')
      decstr = decstr.strip()
      if len(x) == 5 :   # avoid screwed-up images e.g. those biases that didn't see the telescope
         osexp = osexposure(f)
      #   osexp.telescope_cel = celest([rastr,decstr,x[2].strip()])
      #   print "telescope_cel ",summarystring(osexp.telescope_cel)
         equinox = float(x[2])
         if equinox == 2000. : 
             osexp.telescope_cel = coo.SkyCoord(rastr,decstr,unit=(u.hourangle,u.deg))  # defaults to ICRS
         else :
             eqtime = Time(equinox,format='jyear')
             telframe = tsu.currentFK5frame(eqtime) 
             osexp.telescope_cel = coo.SkyCoord(rastr,decstr,unit=(u.hourangle,u.deg),frame = telframe)
             osexp.telescope_cel.transform_to('icrs')

     #   if osexp.telescope_cel.equinox != 2000. : osexp.telescope_cel.selfprecess(2000.)
         osexp.exptime = float(x[3].strip())
         osexp.imagetyp = x[4].strip()
     #    print hselout
     #    print osexp.cel.summarystring(),osexp.exptime,osexp.imagetyp
            
         hselout = hselect(f,"title,jd,filter1,filtid1,filter2,filtid2,dispid,rotangle","yes",Stdout = 1)
         x = hselout[0].split('\t')
         osexp.title = x[0]
         if osexp.title.find("Telescope Focus") > -1 : osexp.isfocus = True
         osexp.jd = float(x[1])
         osexp.filter1 = int(x[2])
         osexp.filter1id = x[3].strip()
         osexp.filter2 = int(x[4])
         osexp.filter2id = x[5].strip()
         osexp.disperser = x[6]
         osexp.rotangle = float(x[7].strip())

         hselout = hselect(f,"slitid,mirror,lamps,naxis1,naxis2","yes",Stdout = 1)
         # print f,"hselout",hselout
         x = hselout[0].split('\t')
         osexp.slit = x[0].split()
         osexp.mirror = x[1].strip()
         osexp.lamps = x[2].strip()
         osexp.naxis1 = int(x[3])
         osexp.naxis2 = int(x[4])

         osexp.set_target_cel()

#         print osexp.slit,osexp.rotangle,'tel:',osexp.telescope_cel.summarystring(),'obj',osexp.cel.summarystring()

        # print osexp.naxis1, osexp.naxis2
         try : 
            osexp.roi = roidict[(osexp.naxis1, osexp.naxis2)]   # tuple works as key
         except : 
            print "unknown ROI, naxis1/2 = ",osexp.naxis1,osexp.naxis2
         all_exposures.append(osexp)

         if osexp.slit[0].upper() != "OPEN" and  osexp.disperser.upper() != "OPEN" :

             # construct a string with slit and disperser and use 
             # it as the key to a dictionary, which will group by setup.

             slitdisperser= " ".join(osexp.slit)
             slitdisperser = "%s %s" % (slitdisperser,osexp.disperser)
             slitdisperser = slitdisperser.strip()
             slitdisperser = slitdisperser.replace('"','')
             slitdisperser = slitdisperser.replace(' ','_')
             slitdisperser = slitdisperser + osexp.roi   # include roi here
             slitdisperser = slitdisperser.strip()
             if slitdispdict.has_key(slitdisperser) : 
                 slitdispdict[slitdisperser].append(osexp)
             else :
                 slitdispdict[slitdisperser] = [osexp]

# Determine type of each exposure, using imagetyp keywords and internal evidence from
# lamps, etc.   Load each to the appropriate list.

         if osexp.imagetyp == "OBJECT" :
           # guard against some mistakes e.g. mislabeled comps and flats
            if osexp.mirror == "IN" :  # can't be an object with the mirror in!
               if osexp.lamps == "Flat" and osexp.disperser.upper() != "OPEN" and osexp.slit[0].upper() != "OPEN" : 
                  osexp.imagetyp = "FLAT"
               if osexp.lamps != "Flat" and osexp.lamps != "Off" and osexp.disperser.upper() != "OPEN" \
	                    and osexp.slit[0].upper() != "OPEN" : 
                  osexp.imagetyp = "COMP"
               print "Mirror in on object:", osexp.fname, osexp.lamps
            if osexp.imagetyp == "OBJECT" :  # still, after error corrections ... 
               all_objectexps.append(osexp)

         # capitalization of Open, open etc is inconsistent
         if osexp.imagetyp == "FLAT" :
            # print "mirror, disperser, slit", osexp.mirror, osexp.disperser, osexp.slit
            if osexp.mirror == "OUT" : 
               if osexp.disperser.upper() != "OPEN" and osexp.slit[0].upper() != "OPEN" : 
                  all_slitflats.append(osexp)
               if osexp.disperser.upper() == "OPEN" and osexp.slit[0].upper() == "OPEN" :
                  all_dirflats.append(osexp)
            if osexp.mirror == "IN" : 
               if osexp.disperser.upper() != "OPEN" and osexp.slit[0].upper() != "OPEN" : 
                  all_misflats.append(osexp)

         if osexp.imagetyp == "COMP" :
            # print osexp.lamps
            all_comps.append(osexp)

         if osexp.imagetyp == "BIAS" : 
            all_biases.append(osexp)
   
         if osexp.imagetyp == "DARK" :
            all_darks.append(osexp)

print "You have %d object exposures, " % (len(all_objectexps))
print "         %d MIS flats, " % (len(all_misflats))
print "         %d slit balance flats, " % (len(all_slitflats))
print "         %d comp exposures, " % (len(all_comps))
print "         %d direct flats, " % (len(all_dirflats))
print "         %d dark exposures, " % (len(all_darks))
print "     and %d bias exposures. " % (len(all_biases))

# This is a lazy way to look for adjacent comps but it's 
# easy to code and plenty fast enough.  Farther down (during the
# flatfielding loop) these get put out into text files for
# later use in setting the wavelength scale.

# print("Searching for adjacent comps.")

critsep = coo.Angle(20. * u.arcmin) 

for o in all_objectexps :
    for c in all_comps :
        # Have occasionally used 'COMP' tag for fringe exposures; those are not 
        # comps, obviously.
        if o.disperser == c.disperser and o.slit == c.slit and c.lamps.find("Flat") < 0:
            if abs(o.jd - c.jd) < 0.1 : # allow for interpolation
                if o.telescope_cel.separation(c.telescope_cel) < critsep :
                    if o.adjacent_comps == None :
                        o.adjacent_comps = [c]
                    else : 
                        o.adjacent_comps.append(c)

# print("Finished searching for adjacent comps.")

def cels_match(cel1, cel2, arcmin_tolerance) : 

#    says whether two SkyCoords match within tolerance.

     critsep = coo.Angle(arcmin_tolerance * u.arcmin)

     if cel1.separation(cel2) < critsep : return True
     else : return False
 
# This commented-out code is from osmosinventory -- it sorts by object and
# so on.  
 
# for o in all_objectexps : 
#    matched = False
#    for g in all_objgrps : 
#       if cels_match(o.cel,g.cel,15.) : 
#          matched = True
#          g.osexps.append(o)
#    if not matched : 
#       all_objgrps.append(objgrp(o))
# 
# objdict = {}
# 
# for g in all_objgrps :
#    objdict[g.cel.ra.val] = g
# 
# objkeys = objdict.keys()
# 
# objkeys.sort()
# 
# print "Groups: "
# 
# for k in objkeys :
#    g = objdict[k]
#    i = 0
#    print g.cel.summarystring()
#    nonfocus_found = False
# #    while not nonfocus_found and i < len(g.osexps) : 
#    while i < len(g.osexps) : 
#       o = g.osexps[i]
#       if not g.osexps[i].isfocus :
#          nonfocus_found = True
#          print "%17s %15s " % (o.fname,o.title),
#          print "%4s " % o.roi,
#          if o.slit[0].upper() == 'OPEN' :
#             print "    open     ",
#          else :
#             print "%4s %7s " % (o.slit[0],o.slit[1]),
#          print " %14s " % (o.disperser),
#          print " %7s %7s " % (o.filter1id, o.filter2id)
# 
#       i = i + 1
#    print " "
# 
# print " "
# print " "
# print " ***************** MIS FLATS *************** "
# print " " 
# print " " 
# 
# for o in all_misflats :
#   print "%17s %15s " % (o.fname,o.title),
#   print "%4s " % o.roi,
#   if o.slit[0] == 'open' :
#      print "    open     ",
#   else :
#      print "%4s %7s " % (o.slit[0],o.slit[1]),
#   print " %14s " % (o.disperser),
#   print " %7s %7s " % (o.filter1id, o.filter2id)
# 
# print " "
# print " "
# print " ***************** SLIT BALANCE FLATS *************** "
# print " " 
# print " " 
# 
# for o in all_slitflats :
#   print "%17s %15s " % (o.fname,o.title),
#   print "%4s " % o.roi,
#   if o.slit[0] == 'open' :
#      print "    open     ",
#   else :
#      print "%4s %7s " % (o.slit[0],o.slit[1]),
#   print " %14s " % (o.disperser),
#   print " %7s %7s " % (o.filter1id, o.filter2id)
# 
# print " "
# print " "
# print " ***************** DIRECT FLATS *************** "
# print " " 
# print " " 
# 
# for o in all_dirflats :
#   print "%17s %15s " % (o.fname,o.title),
#   print "%4s " % o.roi,
#   if o.slit[0].upper() == 'OPEN' :
#      print "    open     ",
#   else :
#      print "%4s %7s " % (o.slit[0],o.slit[1]),
#   print " %14s " % (o.disperser),
#   print " %7s %7s " % (o.filter1id, o.filter2id)
# 
# print " "
# print " "
# print " ***************** DARKS *************** " 
# print " " 
# print " " 
# 
# for o in all_darks :
#   print "%17s %15s " % (o.fname,o.title),
#   print "%4s " % o.roi,
#   if o.slit[0] == 'open' :
#      print "    open     ",
#   else :
#      print "%4s %7s " % (o.slit[0],o.slit[1]),
#   print " %14s " % (o.disperser),
#   print " %7s %7s " % (o.filter1id, o.filter2id)
# 
# print " "
# print " "
# print " ***************** BIASES *************** " 
# print " " 
# print " " 
# 
# for o in all_biases :
#   print "%17s %15s " % (o.fname,o.title),
#   print "%4s " % o.roi,
#   if o.slit[0] == 'open' :
#      print "    open     ",
#   else :
#      print "%4s %7s " % (o.slit[0],o.slit[1]),
#   print " %14s " % (o.disperser),
#   print " %7s %7s " % (o.filter1id, o.filter2id)
# 
# print " "
# print " "
# print " ***************** COMPS *************** " 
# print " " 
# print " " 
# 
# for o in all_comps :
#   print "%17s %15s " % (o.fname,o.title),
#   print "%4s " % o.roi,
#   if o.slit[0].upper() == 'OPEN' :
#      print "    open     ",
#   else :
#      print "%4s %7s " % (o.slit[0],o.slit[1]),
#   print " %14s " % (o.disperser),
#   print " %7s %7s " % (o.filter1id, o.filter2id)
 
print " "
print " "
print " ***************** SLIT/DISP *************** " 
print " " 
print " " 

todokeys = slitdispdict.keys()

# todokeys are names of the setups to do, e.g. "1.4_outer_Red_Grism4x1k"

# print "Before removal: todokeys = ",todokeys

for k in setups_to_omit :
   try :
       todokeys.remove(k)
       print("removed setup %s from processing." % (k))
   except :
       print("Couldn't remove setup %s" % (k))

# Finally, flatfield.

for k in todokeys : 
# for k in ["1.4_outer_Red_Grism4x1k"] : 

    print " "
    print " ******** ",k," ********* "
    print " "
 
    if k in noflatfield :
        doflatfield = False
    else :
        doflatfield = True
   
    normflatname = "normflat_%s.fits" % k

    # Compfile will be a file of adjacent comps with the same setup, e.g.
    # if ki0123 was taken with comps ki0122 before and ki0124 after, there
    # will be a line reading 
    #  ki0123  ki0122 ki0124  
    # If not bracketed, only one will be listed.  This will allow interpolation
    # to be coded in the future if need be.
    # The thought at this point (2019 Aug) is to set up infrastructure for
    # shifting the scale and zeropoint of a master comp using short expsoures
    # of some bright comp lamp, e.g. for inner blue using short HgNe to shift
    # a master solution.

    compfile = open("adjacent_comps_%s" % k,"w")

    misflatlist = []
    slitflatlist = []
    toflattenlist = []
    objectlist = []
 
    if doflatfield : 
       if not os.path.exists(normflatname) :
           noflatfound = True
           print("Flat %s does not exist.  Will make one." % normflatname)
           print("  ")
   
       else : 
           noflatfound = False
           print("Flat %s found already made, will use it." % normflatname)
    else :
       print("Skipping the flatfield for this setup (%s)." % (k))
       noflatfound = True  # need to initialize this.

    for o in slitdispdict[k] :    
        o.set_reduced_name(prefix)
        print "%17s %15s " % (o.reducedname,o.title),
        print "%4s " % o.roi,
        if o.slit[0].upper() == 'OPEN' :
            print "    open     ",
        else :
            print "%4s %7s " % (o.slit[0],o.slit[1]),
        print " %14s " % (o.disperser),
        print " %7s %7s " % (o.filter1id, o.filter2id)

        if doflatfield :
            if o in all_misflats : 
               misflatlist.append(o.reducedname)
            elif o in all_slitflats :
               slitflatlist.append(o.reducedname)
            elif o in all_objectexps or o in all_comps :
               toflattenlist.append(o.reducedname)

        if o in all_objectexps :
           objectlist.append(o.reducedname)
           allobjdict[o.num] = o   # have to do this here because 
                                   # o.num is not set earlier.

        # And here, finally, grab the raw spectrum, bias it,
        # and save it in its reduced form.

        if not args.listonly : 
            # print "o.fname: ",o.fname
            osb.biasquads(o.fname,o.reducedname + ".fits")

        # write a refspec-like file of adjacent comps if there are any. 
        # This is infrastructure for data with adjacent comps, which 
        # as of 2019 Aug I don't have.

        if o.adjacent_comps != None :

            compfile.write("%s " % (o.reducedname))
   
            # Rigarmarole to get only nearest comp before and nearest after.

            nearest_before = None
            nearest_after = None
            min_interval_before = 1.e6
            min_interval_after = 1.e6
            
            for c in o.adjacent_comps :
                c.set_reduced_name(prefix)
                if (c.jd < o.jd) : 
                   if (o.jd - c.jd) < min_interval_before :
                       min_interval_before = o.jd - c.jd 
                       nearest_before = c.reducedname
                if( c.jd > o.jd) :
                   if (c.jd - o.jd) < min_interval_after :
                       min_interval_after = c.jd - o.jd
                       nearest_after = c.reducedname
            
            if nearest_before != None : 
                compfile.write(" %s " % (nearest_before))
            if nearest_after != None : 
                compfile.write(" %s " % (nearest_after))
            compfile.write("\n")
                
    compfile.close() 

    if doflatfield : 
       print "misflats:",misflatlist
       print "slitflats:",slitflatlist

    # save object image roots to a file for further processing.
    osf.list_to_file(objectlist,"obj_%s" % (k))
 
    if doflatfield and noflatfound and (not args.listonly):
        print("Making flat for %s" % k)
        osf.make_spec_flat(misflatlist, slitflatlist, k) 

    if doflatfield and (not args.listonly): 
        print("Flatfielding data for %s" % k)
        for imname in toflattenlist : 
            osf.osflatten(imname + ".fits",normflatname) 



# NEW in 2019 July -- explicitly set the telescope and object
# coordinates, which are not the same unless you're in the center slit.

# ALSO take the opportunity to set the barycentric corrections.
# For right now we'll also have to do this later (since I have data
# farther along where this wasn't done at this stage) but that
# code can be changed later.

if not args.listonly :
    for o in all_objectexps :  # all setups. 
        if o.reducedname != None :  # somehow these creep in?
            # print "header mod, o.reducedname = ",o.reducedname
            hdu = fits.open(o.reducedname + ".fits",mode="update") 
            hdr = hdu[0].header
            # it's not flushing right for some reason.  Try calling hdu[0].header
            # by name.
            hdu[0].header['telra'] = hdr['ra']
            hdu[0].header['teldec'] = hdr['dec']
            hdu[0].header['teleqnx'] = hdr['equinox']
            hdu[0].header['objra'] = o.cel.ra.to_string(unit=u.hourangle,sep=":",pad=True,precision=1)
            hdu[0].header['objdec'] = o.cel.dec.to_string(unit=u.deg,sep=":",pad=True,precision=0)
            hdu[0].header['objeqnx'] = 2000.
            
            # The new (2018-19) JRT astropy-based 'Observation' class.
            obs = tsc3.Observation()

            obs.setcelest(o.cel)
          
            jdmid = hdr['jd'] + hdr['exptime'] / (86400. * 2)    # geocen jd of mid exp
            obs.settime(jdmid)
            obs.computequickbary()
            
            hdu[0].header['jdmid'] = jdmid
            hdu[0].header['hjd'] = obs.tbary.jd
            hdu[0].header['vhelio'] = obs.baryvcorr.value  # born in km/s so this is OK.
            hdu[0].header['hcv'] = obs.baryvcorr.value 
            
            hdu.flush()
            hdu.close()
         
if args.listonly:  # convenient summary at the end for setting up.

   print(" ")
   print(" ******************  SUMMARY: *****************")
   print(" ")
   print("Reduction will include these subdirectories:") 
   print("  ")
   for d in included_dirs :
       print d
   print("  ")

   print("Here are the slit/disperser/region combinations and what")
   print("actions are anticipated for them:") 
   print("  ")
   if len(setups_to_omit) > 0 :
      print("  *** these are to be skipped ***")
      for k in setups_to_omit : 
         print("%s" % k)
      print("  ")
   print(" *** these are to be reduced. ***")
   print("  ")
   for k in todokeys :
      print("%s" % k)
   print("  ")
   print("If you want to skip any of those setups, list them in")
   print("'osmosspecred.config' with the OMITSETUP keyword.")
   print(" ")
   print("e.g. 'OMITSETUP | 1.4_outer_Red_Grism4x1B'")
   print(" ")

   # write out a file in the format I use for my archive list.
   # Tripped over a bug here first time I used this 'in anger'
   # since I had only one night.  
   
   if len(dirnums) >= 2 : 
      keyfilename = "SpecKey%d_%d" % (dirnums[0],dirnums[-1])
   elif len(dirnums) == 1 :
      keyfilename = "SpecKey%d" % (dirnums[0])
   else :
      keyfilename = "SpecKey"

   keyfile = open("%s" % (keyfilename), "w")
   keez = allobjdict.keys()
   keez.sort()
   for k in keez :
       o = allobjdict[k] 
       outline = "%s  %4d   %13.5f " % (o.reducedname, o.num, o.jd)
       #coostring = o.cel.summarystring(delin=':',radigits=1, include_eq=1) 
       coostring = o.cel.ra.to_string(unit=u.hourangle,sep=":",precision=2,pad=True) 
       if o.cel.dec.degree > 0 : coostring = coostring + '   '
       else : coostring = coostring + '  '    #  allow extra space for minus sign
       # these are always returned in ICRS so can simply print the equinox.
       coostring = coostring + o.cel.dec.to_string(unit=u.deg,sep=":",precision=1,pad=True) + " 2000."
       outline = outline + coostring
       outline = outline + " %5.0f  None %s" % (o.exptime,o.title)
       keyfile.write("%s\n" % outline)
   keyfile.close()

   print("Listed exposures in archive form in file %s." % (keyfilename))
