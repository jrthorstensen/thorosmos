#!/usr/bin/env python
"""convel.py - module to replace convrv if needed.

vel, velerr = specvel(filename, band (0-indexed), restw, lined (pix),
   samwid (pix), etc.

vel, velerr  = specvel('dho133.fits',0,6562.817,linwid = 22,samwid=5,
      half_wid = 80, search_wid = -1., is_emission=True, 
      algorithm = 'dgau', rootsearch = True, do_error = True, 
      rootsearchwidth=10.,
      debug = False, helio_correct = True)

"""

import numpy as np
import numpy.polynomial.legendre as leg
import scipy.signal as scpsig
from astropy.io import fits
import sys
import glob

# import matplotlib.pyplot as plt  # remove when done with debugging raw_error

def getwatkey(header, watno) :
   # Grab all the WATm_nnn keywords, and glom their values together to a 
   # single string; m = watno, and nnn = e.g. 001, 002, 003 until done.
   # see documentation at http://iraf.net/irafdocs/specwcs.php.  
   watstring = ""
   nline = 1
   still_reading = True
   while still_reading :
    
      keywordstring = "WAT%d_%03d" % (watno, nline) 
      # Pyfits 3.1+ disposes of a huge amount of nonsense here.  
      # header[keywordstring] simply returns the value , so the whole set of 
      # WAT keywords can be pasted together in a straightforward manner.

      # OLD COMMENT
      # This [WAS] really nasty, because pyfits' header reader strips trailing 
      # spaces from single-quoted strings.  So I have to grab the card and
      # parse out the value myself by looking for the stuff between the single
      # quotes.
      cardstring = ""
      try :
         # card = header.ascard[keywordstring]
         # print "keywordstring:",keywordstring
         # print "card:",card
         card = header[keywordstring]
         # print "card_test:",card_test
         # cardstring = "%s" % (card)    # write it into a string to make iterable
         # print "cardstring:", cardstring
         # card_test_string = "%s" % (card_test)
      except :
         still_reading = False
      if still_reading :
#          value = ""
#          insinglequotes = False
#          enteringsinglequotes = False
#          for c in cardstring :
#             if c == "'" : 
#                insinglequotes = True
#                enteringsinglequotes = True
#             if insinglequotes and not enteringsinglequotes and c == "'" : 
#                insinglequotes = False
#             if insinglequotes and c != "'" :  
#                enteringsinglequotes = False
#                value = value + c
#               
#          watstring = watstring + value
           watstring = watstring + card
         
      nline = nline + 1
    
   return watstring

def getkeyw(instr,keyword) :   
   # takes a WAT string -- which has little "keyw=value" pairs embedded in it --
   # and grabs the keyword's value.
   if instr.find(keyword) > -1 :
      # print instr, keyword
      pieces = instr.split(keyword)
      # print "pieces = ",pieces
      value = ""
      ind = 0 
      end_found = False
      start_found = False
      while not end_found and ind < len(pieces[1]):
        c = pieces[1][ind]
       #  print "c = ",c,"ind = ",ind,"start found",start_found,"end_found",end_found
        if c != '=' and c != ' ' :
           value = value + c
           start_found = True
        if c == ' ' and start_found :
           end_found = True
        ind = ind + 1
      return value  

class dispersion_func :  # a single non-linear dispersion function
   def __init__(self, weight, zptoffset, functype) :
      self.weight = weight;
      self.zptoffset = zptoffset
      self.functype = functype
      if self.functype != 2 : 
         print "WARNING: Only legendre functions implemented."
      self.ncoeffs = None
      self.pmin = None
      self.pmax = None
      self.coeffs = [] 
      self.legpoly = None 

# leg.Legendre(self.coeffs,domain = [self.pmin,self.pmax])

class dispersionsoln : 

   # all the information on a dispersion solution, but limited to 
   # either linear binned 1-d spectra or nonlinear unbinned that
   # have legendre polynomial solutions.  It would not be too
   # difficult to implement chebyshevs, but I've never used them.
   # Assumes headers were prepared with IRAF's identify -- uses their
   # idiosyncracies.  
   #  
   # Much of the parsing below is heavily informed by 
   #  http://iraf.net/irafdocs/specwcs.php

   def __init__(self, header, mollydata = None, verbose = False) :  

       self.verbose = verbose 

       # mollydata, if set, is the whole hdulist.
       if mollydata != None :
          self.is_molly = True   # it is a molly spec converted by IDL routine.
          # pull out the first column of the data, which is the wavelength vs. pixel.
          # this appears to be an evaluation of a polynomial fit, but we're just gonna
          # take it literally.
          arrshape = mollydata[0].data.shape
          self.wavlenarray = mollydata[0].data[0:arrshape[0]-1,0]    
          self.is_calibrated = True
          self.is_simple_linear = False
       else : 
          self.is_molly = False
          self.wavlenarray = None  # for straight interpolation, e.g. molly spectra.
          self.is_linear = False
          self.is_simple_linear = False
          wat1 = getwatkey(header, 1) # check to see if there is a wln calib
          # print "wat1 : ", wat1
          labelval = getkeyw(wat1, "label")
          self.is_calibrated = True
          try :  # this is at least one case in which the data are not calibrated,
                 # but it throws an exception in some cases. So we make 'is_calibrated'
                 # true by default and then turn it off if this works.
             if labelval.find('ixel') > -1 : self.is_calibrated = False
          except :
             pass
          if self.is_calibrated :
             wat3 = getwatkey(header, 3) 
      #       print "wat3 = ",wat3
             if wat3 != "" :
                 wtype = getkeyw(wat3,"wtype")
                 if wtype == "linear" :  self.is_linear = True
                 try :
                    self.cd1_1 = header['cd1_1']
                    self.crval1 = header['crval1']
                    self.crpix1 = header['crpix1']
                    self.is_simple_linear = True
                 except :  # apparently cd1_1 etc are always there if wtype=='linear'
                    self.crval1 = 0.
                    self.crpix1 = 0.
                    self.wat2 = getwatkey(header, 2)
                    self.is_simple_linear = False
             # very old data (e.g. 1997) have the spec1 stuff in WAT2_001
             if not self.is_simple_linear : # has not been put into uniform wln bins
                 self.wat2 = getwatkey(header, 2)
                 if self.verbose : print "self.wat2 = ",self.wat2
                 self.parsespec1(self.wat2)
               
   def printsummary(self) :
       if self.is_molly :
          print self.wavlenarray[0],self.wavlenarray[1],len(self.wavlenarray)
       else :
          if not self.is_calibrated :
             print "No wavelength calib."
          elif self.is_simple_linear :
             print self.crval1, self.crpix1, self.cd1_1
          else :
             # print self.wat2
             self.parsespec1(self.wat2)
   
   def parsespec1(self,watstring) :  # parse the God-awful spec1 string
       if watstring.find("spec1") > -1:
          pieces = watstring.split("spec1")
          inquote = False 
          quotedpart = ''
          for c in pieces[1] :
             if inquote == True and c == '"' : inquote = False
             if c == '"' : inquote = True
             elif inquote : quotedpart = quotedpart + c
#          print "spec1 = ",quotedpart
          x = quotedpart.split()
          self.ap = int(x[0])
          self.beam = int(x[1])
          self.dtype = int(x[2])
          self.w1 = float(x[3])
          self.dw = float(x[4])
          self.nw = int(x[5])
          self.z = float(x[6])
          self.aplow = float(x[7])
          self.aphigh = float(x[8])
          if self.verbose : 
              print "spec1 parses as :"
              print "ap = ", self.ap, "beam = ", self.beam, "dtype =  ", self.dtype 
              print "w1 = ", self.w1, "dw = ", self.dw,  "nw =  ", self.nw 
              print "z = " , self.z, "aplow = ", self.aplow, "aphigh = ", self.aphigh
          if self.dtype == 0 : self.is_linear = True
          if (self.dtype > 1) : # non-linear dispersion
             self.is_linear = False
             # initialize arrays for more than one disp func
             self.dispersion_funcs = []  # list of dispersion funcs
             next_index = 9  # next to read
             all_funcs_read = False 
             while not all_funcs_read :
                try :
                   weight = float(x[next_index])
                   next_index = next_index + 1
                   zptoffset = float(x[next_index])
                   next_index = next_index + 1
                   functype = int(x[next_index])
                   next_index = next_index + 1
                   # print "weight, offset type",weight,zptoffset,functype
                   thisfunc = dispersion_func(weight, zptoffset, functype)
                   # print x[next_index]
                   thisfunc.ncoeffs = int(x[next_index])
                   # print "1 ... "
                   next_index = next_index + 1
                   thisfunc.pmin = float(x[next_index])
                   next_index = next_index + 1
                   thisfunc.pmax = float(x[next_index])
                   # print "pmin, pmax %f %f" % (thisfunc.pmin,thisfunc.pmax)
                   next_index = next_index + 1
                   for i in range(0, thisfunc.ncoeffs) :
                       thisfunc.coeffs.append(float(x[next_index]))      
                       next_index = next_index + 1

                   if self.verbose :
                       print "Nonlinear dispersion: weight %f offset %f type %d" % (thisfunc.weight, 
                        thisfunc.zptoffset, thisfunc.functype)
                       print "Ncoeffs %d pmin %f pmax %f" % (thisfunc.ncoeffs, thisfunc.pmin, thisfunc.pmax)
                       for i in range(0, thisfunc.ncoeffs) :
                           print "coef %d = %f" % (i,thisfunc.coeffs[i])


                   # create the numpy Legendre instance -- remarkably easy!
                   thisfunc.lpoly = leg.Legendre(thisfunc.coeffs,domain = [thisfunc.pmin,thisfunc.pmax])

                   self.dispersion_funcs.append(thisfunc)

                except :
                   all_funcs_read = True
       
       else : print "No spec1 in watstring: %s" % (watstring)

   def evaluate(self,xval) :
      if not self.is_calibrated :
          return xval
      elif self.is_simple_linear :
          try :
             return self.crval1 + self.cd1_1 * (xval - self.crpix1)
          except :  # build in capability of doing a list of channels
             wln_out = []
             for x in xval :
                wln_out.append(self.crval1 + self.cd1_1 * (x - self.crpix1))
             return wln_out
      elif self.is_linear : 
          # print "Using is_linear path."
          # return self.w1 + (self.nw - xval) * self.dw
          return self.w1 + (xval - 1.) * self.dw
             
      elif self.is_molly :
         if xval > 0. and xval < len(self.wavlenarray - 1) :
            lowint = np.floor(xval)
            frac = xval - lowint
            dw = self.wavlenarray[lowint + 1] - self.wavlenarray[lowint]
            return self.wavlenarray[lowint] + frac * dw  # linear interp plenty good.
         else :
            return 0.
      else :
         if self.dtype == 2 :
            wln_out = 0.
            for d in self.dispersion_funcs : # sum the contributions - usually 1.
                wln_out = wln_out + d.weight * d.lpoly(np.array(xval)) 
            return wln_out
         else :
            print "Unimplemented dispersion type %d -- only have legendre (2)" % self.dtype
           
   def channel(self,inwav) :  # supports arrays of inwavs for simple linear.
      # find the channel for a given wavelength.
      # if no wavelength calibration, just return the input value.
      if not self.is_calibrated :
         # print "No wavelength calibration -- returning inwav."
         return inwav
      elif self.is_simple_linear :
         try :
             pixout = self.crpix1 + ((inwav - self.crval1) / self.cd1_1)
         except :
             pixout = []
             for w in inwav :
                pixout.append(self.crpix1 + ((w - self.crval1) / self.cd1_1))
         return pixout
      elif self.is_linear :  # for the old (1997) data
         # print "using is_linear; inwav = %f, w1 = %f, dw = %f, nw = %f" % (inwav, self.w1, self.dw, self.nw)
         # pixout = self.nw - (inwav - self.w1) / self.dw
         pixout = (inwav - self.w1) / self.dw
         # print "returning ",pixout
         return pixout
      elif self.is_molly :
         topind = len(self.wavlenarray) - 1
         lastwav = self.wavlenarray[topind]
         firstwav = self.wavlenarray[0]
         # print "firstwav lastwav inwav ",firstwav,lastwav,inwav
         if inwav > firstwav and inwav < lastwav :
            span = lastwav - firstwav
            guess = int(topind * ((inwav - firstwav) / span))
            # print "guess ",guess
            while self.wavlenarray[guess] > inwav :
                guess = guess - 1
            while self.wavlenarray[guess + 1] < inwav :
                guess = guess + 1
            # guess SHOULD now be the index of the next-lowest one 
            dw = self.wavlenarray[guess + 1] - self.wavlenarray[guess]
            pixout = guess + (inwav - self.wavlenarray[guess]) / dw
            # print "pixout ",pixout
            return pixout
      else :
         # to invert legendre, subtract the wavelength you want, use numpy's
         # root-finder, and then make sure one of the roots is within the
         # pixel range.
         if self.dtype == 2 :
            pixout = 0.
            for d in self.dispersion_funcs :
                templeg = d.lpoly - inwav
                rtarr = np.real(templeg.roots())
                # print "rtarr:", rtarr 
                root_found = False
                inrange_root = None
                for r in rtarr : 
                   if r > d.pmin and r < d.pmax : 
                      root_found = True
                      inrange_root = r
                if root_found :
                   pixout = pixout + d.weight * inrange_root
                else :
                   print "No roots in range!"
            return pixout
         else : 
            print "dispersionsoln.channel - non-Legendre functions not yet supported."

def gaussian(x, fwhm) :  # un-normalized gaussian, centered at zero.
                         # note that fwhm is not the sigma.  Code transcribed from 
                         # Convrv, mostly.
   ponent = -2.77259 *  (x/fwhm) ** 2
   if abs(ponent) > 40. : return 0.
   return np.exp(ponent)

def convfunc(x, linwid, samwid, algorithm) :
   
   if algorithm.find('dg') > -1 :
      dgw = linwid / 1.41421 
      return -1. * x * gaussian(x,dgw)
   elif algorithm.find('gau2') > -1 :
      return gaussian(x - linwid/2.,samwid) - gaussian(x + linwid/2., samwid)

def convolve(ctr, array, linwid, samwid, algorithm) :
   
   result = 0.
   for i in range(0, len(array)) :
      arg = ctr - i
      result = result + array[i] * convfunc(arg, linwid, samwid, algorithm)
      # print "i array[i] convfunc ",i,array[i],convfunc(arg, linwid, samwid, algorithm)
   return result

def propagate_err(ctr, uncertainties, linwid, samwid, algorithm) :
   result = 0.
   for i in range(0, len(uncertainties)) :
      arg = ctr - i
      result = result + (uncertainties[i] * convfunc(arg, linwid, samwid, algorithm)) ** 2.
   return np.sqrt(result)
    
def converge(starting_ctr, array, uncertainties, linwid, samwid, algorithm, rootsearch = True,
        rootsearchwidth = 10., debug = False) :
   
   dx = 0.01
   guess = starting_ctr
   if debug:  print "starting guess = ",guess," linwid, samwid = ",linwid,samwid
   niter = 0
   corrn = 1000.
   # scan for a sign change in the convolution and iterate from their --
   # should be more robust.
   if rootsearch :
      testctr = starting_ctr - rootsearchwidth
      sign_change_found = False
      lasty = convolve(testctr, array, linwid, samwid, algorithm)
      if lasty > 0. : last_sign = 1
      else : last_sign = -1
      while testctr < starting_ctr + rootsearchwidth and not sign_change_found:
         testctr = testctr + 1.
         y = convolve(testctr, array, linwid, samwid, algorithm)
         if debug: print "testctr %f y %f lastsign %d" % (testctr,y,last_sign)
         if y > 0 : sign = 1
         else : sign = -1
         if sign != last_sign :
            sign_change_found = True
            slope = y - lasty
            if debug : print "lasty %f y %f slope %f" % (lasty,y,slope)
            guess = testctr - y / slope
            if debug : print "interpolated root as ",guess
         else :
            last_sign = sign
            lasty = y
      if not sign_change_found :  
         print "Warning -- convolution function root not found."
   
   while niter < 10 and abs(corrn) > 1.0e-4 :
      y1 = convolve(guess, array, linwid, samwid, algorithm)
      y2 = convolve(guess + dx, array, linwid, samwid, algorithm)
      if debug : print "y1, y2, ",y1,y2,
      deriv = (y2 - y1) / dx
      corrn = y1 / deriv
      if debug : print "deriv, corrn ",deriv,corrn
      guess = guess - corrn
      if debug : print "new guess ", guess
      niter = niter + 1

   if len(uncertainties) > 0 :
      sumsq = propagate_err(guess, uncertainties, linwid, samwid, algorithm)
      error_est = sumsq / deriv
      if debug : print "sumsq, deriv, error est: ",sumsq,deriv,error_est
   else : error_est = -1.

   # test = convolve(guess, array, linwid, samwid, algorithm)
   # print "test = ",test

   return guess,error_est
   

def centerpixel(pixarray, nominal_center, half_wid = 20., search_wid = 8., 
                algorithm = 'dgau', linwid = 6., samwid = 3., is_emission = True,
                uncertainties = [],
                rootsearch = True, rootsearchwidth = 10., debug = False) :

    if debug : print "centerpixel: is_emission = ",is_emission

    # build pixel array
    centarr = []
    uncertarr = []
    firstpix = int(nominal_center - half_wid)
    if firstpix < 0 : firstpix = 0
    lastpix = int(nominal_center + half_wid)
    if lastpix > len(pixarray) :  lastpix = len(pixarray) 
    # kount = 0
    if debug : print "first and last pix = ",firstpix, lastpix
    if debug : print "len(uncertainties) = ",len(uncertainties)
    for i in range(firstpix, lastpix) :
       centarr.append(pixarray[i])
       if len(uncertainties) > 0 :
          uncertarr.append(uncertainties[i])
       # print "kount, i, pixarr[i] = ",kount,i, pixarray[i]
       # kount = kount + 1
    
    if debug : print "uncertarr:",uncertarr
    if debug : print "nominal center:",nominal_center
 
    centarr_nominal = nominal_center - firstpix  
    # startind = centarr_nominal 
    extremum_ind = int(centarr_nominal)
    
    if search_wid > 0. :
       firstsearch = int(centarr_nominal - search_wid)
       if firstsearch < 0 : firstsearch = 0
       lastsearch = int(centarr_nominal + search_wid)
       if lastsearch > len(centarr) : lastsearch = len(centarr)
       max_val = -1.0e30
       min_val = 1.0e30  
       # print "looking for max or min over",firstsearch, lastsearch
       for i in range(firstsearch,lastsearch) :
          # print i, centarr[i],is_emission
          if is_emission :
             if centarr[i] > max_val : 
                max_val = centarr[i]
                extremum_ind = i
          else :
             if centarr[i] < min_val :
                min_val = centarr[i]
                # print "i min ",i,min_val
                extremum_ind = i

    # print "extremum_ind = ",extremum_ind,"max min vals ",max_val,min_val
    if debug : print 'max or min: ', extremum_ind + firstpix + 1   # yes, it finds max pixel.
    if debug : print "linwid, samwid in centerpixel = ",linwid, samwid
    
    ctrpix,pixerr = converge(float(extremum_ind), centarr, uncertarr,  linwid, samwid, algorithm,
       rootsearch = rootsearch, rootsearchwidth = rootsearchwidth, debug=debug) 
    if debug : print "ctrpix = ",ctrpix
  
    # test = convolve(15.8556, pixarray, linwid, samwid, algorithm)
    # print "test of convrv answer = ",test

    return ctrpix + firstpix + 1, pixerr


def linecenter(hdulist, band, dispsolution, restwav, half_wid = 20., search_wid = 8., 
      algorithm = 'dgau', linwid = 5., samwid = 3., is_emission = True,
      rootsearch = True, rootsearchwidth = 10., do_error = True, raw_error = False,
      debug = False) :

   # print "linecenter: raw_error =  ",raw_error

   nominal_center = dispsolution.channel(restwav) 

   if debug : print "nominal center is ",nominal_center,

   arrshape = hdulist[0].data.shape
   if debug : print "arrshape = ",arrshape
   if dispsolution.is_molly :
      pixarray = hdulist[0].data[0:arrshape[0]-1,1]
      if debug : 
         for i in range(0,20) : print pixarray[i]
      uncertainties = hdulist[0].data[0:arrshape[0]-1,2]
      if debug : 
         for i in range(0,20) : print uncertainties[i]
   else :
      uncertainties = []
      if len(arrshape) == 1 :
         pixarray = hdulist[0].data[0:arrshape[0]-1]
      elif len(arrshape) == 3 :
         pixarray = hdulist[0].data[band,0,0:arrshape[2] - 1]
         if do_error :
            try :
               uncertainties = hdulist[0].data[3,0,0:arrshape[2] - 1]
            except :
               do_error = False
   if raw_error :  # fake an error for e.g. a sky line by using sqrt(counts) 
                         # as a crude proxy for the real uncertainty.

         # oops, need to account for the baseline.  Otherwise e.g. tiny
         # lines on very strong background come up with tiny errors.
         # Take the baseline to be the running median in a window 99 pixels
         # wide.  Plotting this (below) shows it works beautifully.
                        
         medwidth=99   # median filter width
         bkgrd = scpsig.medfilt(pixarray,kernel_size = medwidth)
         xaxis = range(0,pixarray.shape[0])
         # The background enters twice; if the signal is s, and
         # the background is b, then we want Var(s) = Var((s + b) - b) =
         # Var(b + s) + Var(b) = (b + s) + b for pure poisson 
         # statistics; then sigma(s) = sqrt(s + 2b).
         
         uncertainties = np.sqrt(pixarray + 2 * bkgrd)
         
         # plot the "uncertainty" for diagnostic.
         #plt.plot(xaxis,pixarray,color='green')
         #plt.plot(xaxis,bkgrd,color='red')
         #plt.plot(xaxis,uncertainties,color='blue')
         #plt.show()
 
   ctrpix, pixerr = centerpixel(pixarray, nominal_center,
        half_wid = half_wid, search_wid = search_wid,
        uncertainties = uncertainties,
        algorithm = algorithm, linwid = linwid, samwid = samwid, is_emission = is_emission,
        rootsearch = rootsearch, rootsearchwidth=rootsearchwidth, debug = debug)
   if debug :print "line center is at ", ctrpix
#   if dispsolution.functype > -1 :
   wln = dispsolution.evaluate(ctrpix)
   if do_error or raw_error:
      wln2 = dispsolution.evaluate(ctrpix + pixerr) 
      wlnerr = wln2 - wln 
#      velerr = 299792.458 * (wlnerr / restwav)
   else :
      wlnerr = None
#      velerr = None
#   else :
#      wln = -1.
   if debug :print "wavelength is ", wln
   if debug : print " "
   return ctrpix, wln, wlnerr

   
def linevel(hdulist, band, dispsolution, restwav, half_wid = 20., search_wid = 8., 
      algorithm = 'dgau', linwid = 5., samwid = 3., is_emission = True,
      rootsearch = True, rootsearchwidth = 10., do_error = True, raw_error = False,
      debug = False, helio_correct = True) :

   # calls linecenter, but surrounds the call with all the specific stuff needed
   # to get a (possibly heliocentric) radial velocity.

   # if debug : print "in linevel, raw_error = ", raw_error

   ctrpix, wln, wlnerr  = linecenter(hdulist,band,dispsolution,restwav,
      linwid = linwid, samwid = samwid,
      half_wid = half_wid, search_wid = search_wid, is_emission= is_emission, 
      algorithm = algorithm, rootsearch = rootsearch, do_error = do_error, 
      raw_error = raw_error,
      rootsearchwidth = rootsearchwidth, debug = debug)

   rawvel = 299792.458 * (wln - restwav) / restwav 
   if debug : print "in linevel : wln %f restw %f rawvel %f" % (wln,restwav,rawvel)
   if helio_correct :
      if dispsolution.is_molly : 
         try : 
            rvcorr = -1. * float(hdulist[0].header['VEARTH'])
         except :
            print 'No rvcorr (is_molly = True)'
      else :
         try :
             rvcorr = float(hdulist[0].header['HCV'])
         except :
             try :
                 rvcorr = float(hdulist[0].header['VHELIO'])
             except :
                 print "No rvcorr!"
   
      if debug: print "rvcorr = %f" % (rvcorr)
      vel = rawvel + rvcorr

   # no helio correction attempted.
   else : vel = rawvel

   if wlnerr != None :
      velerr = 299792.458 * wlnerr / restwav
   else :
      velerr = None
   return vel, velerr

def specvel(fname, band, restwav, half_wid = 20., search_wid = 8., 
      algorithm = 'dgau', linwid = 5., samwid = 3., is_emission = True,
      rootsearch = True, rootsearchwidth = 10., do_error = True, 
      raw_error = False, debug = False,
      helio_correct = True, is_molly = False ) :
 
   hdulist = fits.open(fname)

   hdr = hdulist[0].header
   if is_molly :
      d = dispersionsoln(hdr,mollydata = hdulist)  
   else :
      d = dispersionsoln(hdr,mollydata = None)

   # if debug : print "raw_error = ",raw_error

   vel, velerr = linevel(hdulist, band, d, restwav, half_wid = half_wid, 
      search_wid = search_wid, algorithm = algorithm, linwid = linwid, samwid = samwid, 
      is_emission = is_emission,
      rootsearch = rootsearch, rootsearchwidth = rootsearchwidth, do_error = do_error, 
      raw_error = raw_error,
      debug = debug, helio_correct = helio_correct ) 

   hdulist.close()
   return vel, velerr

if __name__ == "__main__" :

#   vel, velerr  = specvel('SDSS0922_14.fit',0,6562.817,linwid = 22,samwid=5,
#         half_wid = 80, search_wid = -1., is_emission=True, 
#         algorithm = 'dgau', rootsearch = True, do_error = True, rootsearchwidth=10.,
#         debug = True, helio_correct = True)
   
   vel, velerr  = specvel('ki0444.0001.fits',0,6598.953,linwid = 5,samwid=5,
         half_wid = 10, search_wid = -1., is_emission=True, 
         algorithm = 'dgau', rootsearch = True, do_error = False, 
         raw_error = True, rootsearchwidth=10.,
         debug = True, helio_correct = False)

   print "vel, velerr = ",vel, velerr
   
    
   
