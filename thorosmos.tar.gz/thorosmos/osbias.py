#!/usr/bin/env python
"""osbias.py 
   - Task to bias-subtract an OSMOS image and optionally display it.
   - Translated, mostly, from Jason Eastman's IDL routines.  
   - Can be run as a pyraf task with the pyexecute('osbias.py') mechanism.  
      - if used as a pyraf task, leaves result in 'xnnnn.fits' in current 
        directory, rather than data directory.
"""

from pyraf import iraf  # for deployment as a task

# import sys
# import os
import numpy as np
from astropy.io import fits

import matplotlib.pyplot as plt  # for diagnostics

# scipy.interpolate is used only to smooth the bias.
from scipy.interpolate import UnivariateSpline

def IDLrotate(inarr, action) :
    # JE uses an IDL function ROTATE that does 90-degree rotations
    # and/or transpositions, described here:
    # https://www.harrisgeospatial.com/docs/ROTATE.html
    # this uses an integer code for the action taken, as follows:
    # 0-3  - rotations by 0, 90, 180, 270, not transposed
    # 4-7  - rotations by 0, 90, 180, 270, with
    #         transposition applied before rotation.

    if action > 3 :
       out = np.ndarray.transpose(inarr)
    else :
       out = np.copy(inarr)    # careful not to make it a reference only.

    out = np.rot90(out, action % 4)  # % is modulo operator.

    return out


def fixcol(arr, pixlist) :   # pixlist is list of triplets (firsty, lasty, col)
    # interpolates in array arr across column "col" (zero indexed) 
    # from y = firsty to y = lasty.
  
    for p in pixlist : 
        lowcol = arr[p[0]:p[1],p[2]-1]
        hicol = arr[p[0]:p[1],p[2]+1]
        arr[p[0]:p[1],p[2]] = (lowcol + hicol) / 2.
    #    arr[p[0]:p[1],p[2]] = 1000.  # fake for testing
    # return arr



def biasquads(infile, outfile, zero_saturated = False, mask_saturated = False, 
     attempt_saturated_corr = True, showgraph = False, smoothbias = True,
     integer_output = True) :
    """Subtracts bias and optionally corrects saturated pixels for OSMOS 
    data.  Leaves original data alone. 'showgraph' is for diagnostics."""
    
   
    # showgraph is for debugging.

    # Open an image, and get its dimensions.
    
    hduin = fits.open(infile)  # acquisition frame
    
    hdrin = hduin[0].header
    
    arrin = hduin[0].data  # this is a numpy array.
    
    (nyorig,nxorig) = arrin.shape  # get (1016,4128) so (naxisy, naxisx)

    print(arrin.shape)
    
    # Lop off a narrrow strip around the edges, width 'edgetrim'.
    # This will be twice as wide if binned 2x2, but it
    # shouldn't matter.
    
    edgetrim = 4  # width of strip
    
    arr = arrin[edgetrim:nyorig-edgetrim, edgetrim:nxorig-edgetrim]
    
    (ny, nx) = arr.shape
    # print("type of nx and any", type(nx), type(ny))
    
    repaired = np.zeros(arr.shape) 
        # full geometry (minus edgetrim)
    if mask_saturated : 
        maskarr = np.zeros(arr.shape)
        # same.
    
    # Katie Weil's 2018 update of the cross-talk coeffs (from
    # her, 2018-12-19).
    
    # xtcoefflo_weil = np.array([[0.000000000, 0.000413419,0.00187403,0.00187403], 
    #     [0.00032044,0.0000,0.000198742,0.000899782],
    #     [0.00182057,0.000423444,0.0000,0.00201990],
    #     [0.000899807,0.00122840,0.00244887,0.0000]])
    
    # She did NOT redetermine the saturated correction.
    
    # cross-talk coefficients for unsaturated pixels, copied
    # from JE's code
    xtcoefflo = np.array([[0.000000000, 0.000512182, 0.00182688, 0.00123051],
                     [0.000559781, 0.000000000, 0.00037473, 0.00112503],
                     [0.001783810, 0.000417698, 0.00000000, 0.00174711],
                     [0.001234770, 0.001176940, 0.00183285, 0.00000000]])
    
    # Check to see how much they changed by dividing old
    # and new arrays (using fancy indexing trick to avoid
    # non-zero denominators.  This is very powerful.)
    
    # xtlo_ratio = xtcoefflo.copy() 
    
    # nonzero = (xtcoefflo != 0.)  # generate indices of nonzero 
    
    # xtlo_ratio[nonzero] = xtcoefflo_weil[nonzero] / xtcoefflo[nonzero]
    
    # print "Ratio of Weil's coefficients to the old Eastman coeffs:"
    # print xtlo_ratio
    
    ######
    
    # Check to see how symmetric the coeffs are
    
    # initialize with a copy only because it's the same size.
    #xtcoeff_asymmetry = xtcoefflo.copy()  
    
    #xtcoeff_asymmetry[nonzero] = xtcoefflo.T[nonzero] / xtcoefflo[nonzero]
    
    #print "And here's the matrix divided by its transpose."
    #print xtcoeff_asymmetry
    
    # conclusion -- the're pretty close to symmetric.
    
    #######
    
    # try flipping
    # and making correction a bit less
    
    xtcoefflo = xtcoefflo.T  
    
    # transpose is almost undoubtedly correct because numpy 
    # and IDL use opposite row/column order conventions.
    # Hard to tell empirically because matrix is fairly symmetric and corrections
    # are not large in the first place.
    
    #######
    
    # Replace with Weil to see if it makes a difference
    
    # xtcoefflo = xtcoefflo_weil.T
    
    # Yes -- it apparently oversubtracts with 1x1 binned data.
    
    #######
    
    # same for saturated pixels -- he says this won't work well.
    
    xtcoeffhi = np.array([[0.000000000, 0.000665058, 0.00232165, 0.00172752],
                     [0.000582549, 0.000000000, 0.00038356, 0.00119812],
                     [0.001565830, 0.000380083, 0.00000000, 0.00157540],
                     [0.000823900, 0.000669940, 0.00144859, 0.00000000]])
    
    # flip row/column order
    xtcoffhi = xtcoeffhi.T
    
    # table of rotations/transpositions to apply to each
    # quadrant to align with 'victim' quadrant.
    # for use as arguments to IDLrotate.
    # symmetric so row/column order doesn't matter.
    
    rot = np.array([[0,7,5,2],  # This was adjusted empirically from JE's 
                    [7,0,2,5],  # original -- my IDLRotate is different from    
                    [5,2,0,7],  # the original; see notes below.
                    [2,5,7,0]])   
    
    # -- replaced his 5 with my 7 -- worked but made other problems
    # -- replaced his 7 with my 5 --  
    # This seems to have fixed it -- only 0, 7, 5, and 2 preserve
    # the image shape.  0 means "no action" and the only alternative
    # choice for the 2's would be a zero, which would leave things
    # the same.  
    
    # Cut into quadrants using JE's numbering convention

    nyon2 = int(ny/2)  # run into trouble if these aren't expicitly integers
    nxon2 = int(nx/2)  
    
    quadrant = [
    arr[ nyon2:ny, 0:nxon2],  # 0 = upper left 
    arr[ nyon2:ny, nxon2:nx], # 1 = upper right
    arr[ 0:nyon2, 0:nxon2],  # 2 = lower left 
    arr[ 0:nyon2, nxon2:nx]  # 3 = lower right
    ]
    
    # It'll be useful later to have the 
    # array limits indexed by quadrant:
    
    xlo = [0, nxon2, 0, nxon2]
    xhi = [nxon2, nx, nxon2, nx]
    ylo = [nyon2, nyon2, 0, 0]
    yhi = [ny, ny, nyon2, nyon2]
    
    xbin = hdrin['CCDXBIN']
    xover = hdrin['OVERSCNX'] - edgetrim
    
    if xbin != 1 : 
       xover = int(xover / xbin)
    
    # print("xover = ",xover," xbin = ",xbin)
    
    # set up an empty array for bias and trimmed 
    # data.
    
    trimarr = np.zeros((ny, nx - 2 * xover))
    maskout = np.zeros((ny, nx - 2 * xover))
    
    # specify limits in the trimmed array into which 
    # you'll insert the trimmed quads when done.
    # This is simply shifted by width of bias strip
    # at low x.  Since quads 2 and 3 are same as 0 and
    # 1, can call with index  [quadnum%d]
    
    xlotrim = [     0    , nxon2 - xover   ]  
    xhitrim = [nxon2-xover, nx - 2 * xover ]  
    
#    print "xlotrim",xlotrim
#    print "xhitrim",xhitrim
    
    # specify bad columns, now that ny is known.
    
    badcols = []   # list by quadrant.
    badcols.append([])   # quad zero
    badcols.append([[0,nyon2,int(297/xbin)]])  # quad 1; binning not tested
    badcols.append([])
    badcols.append([[nyon2-151,nyon2,int(601/xbin)]])
    
    # quadrants: 
    
    # 0  1
    # 2  3
  
    # Correct the crosstalk!
    
    for i in range(0,4) :
        
        victim = quadrant[i].copy()
    
        maskquad = np.zeros(quadrant[i].shape)  
    
        # save locations of saturated pixels in the raw data for use later
        if zero_saturated or mask_saturated:
            victimhigh = (victim > 65534)  # boolean array of saturated pixels
    
        anyhigh = np.zeros(victim.shape,dtype=bool)  # empty array of "False"
    
      # comment out this loop to cancel crosstalk corrn
        for j in range(0, 4) : 
            if i != j : 
      
                # set up 
    
                source = IDLrotate(quadrant[j],rot[i,j])
                # print("source.shape,",source.shape,"victim.shape",victim.shape)
                victim = victim - source * xtcoefflo[i,j]
    
                # find saturated pixels -- this wonderful trick is described here:
                # https://stackoverflow.com/questions/47162048/numpy-array-apply-a-function-only-to-some-elements
                # keep a record of corrections from saturated pixels, and 'or' them
                # so values can be reset to zero AFTER we loop over source frames.
    
                high = (source > 65534)   # boolean array True only where "source" saturated
    
                if mask_saturated or zero_saturated :       #
                    anyhigh = np.logical_or(high,anyhigh) 
    
                #print "high:",high
                #print "not high:",np.logical_not(high)
    
                # numpy has boolean indexing that just does this!
                # This is apparently the ADDITIONAL correction after the correction 
                # appropriate to unsaturated pixels has already been applied.
    
                elif attempt_saturated_corr : 
                    victim[high] = victim[high] - source[high] * xtcoeffhi[i,j]
         #       print "victim[high].shape",victim[high].shape
    
        if zero_saturated :  # Now go back and zero, both :
            victim[victimhigh] = 0  # pixels that were saturated originally ...
            victim[anyhigh] = 0  # and the ones with ANY corrections derived from a saturated pixel.
      
        if mask_saturated :  # also keep a record in the mask 
            maskquad[victimhigh] = 1
            maskquad[anyhigh] = 1
    
        repaired[ylo[i]:yhi[i],xlo[i]:xhi[i]] = victim
    
        if mask_saturated : 
            maskarr[ylo[i]:yhi[i],xlo[i]:xhi[i]] = maskquad
    
        # may be able to eliminate 'repaired' and go right to trimquad.
        # but for now this is conceptually straightforward.  It's all so fast
        # it doesn't matter.
    
        # subtract median bias
    
        # define arrays for repaired data frame and bias strip.
        if i == 1 or i == 3 :
            biasstrip = repaired[ylo[i]:yhi[i],xhi[i] - xover + 1:xhi[i]]
            trimquad = repaired[ylo[i]:yhi[i],xlo[i]: xhi[i] - xover]
            if mask_saturated :  # and a trimmed mask array too.
               trimmask = maskarr[ylo[i]:yhi[i],xlo[i]: xhi[i] - xover]
        else :
            biasstrip = repaired[ylo[i]:yhi[i], xlo[i]: xlo[i] + xover]
            trimquad = repaired[ylo[i]:yhi[i],xlo[i] + xover:xhi[i]]
            if mask_saturated :  # and a trimmed mask array too.
               trimmask = maskarr[ylo[i]:yhi[i],xlo[i] + xover: xhi[i]]
    
        medianvec = np.median(biasstrip,axis=1)    # median of each row, 
                                               # expressed as a 1-d array

        if smoothbias :   
            # Even though the bias in each line is the average across
            # columns, it still has noise fluctuations that are visible as
            # horizontal striations across the image.  Smoothing it gets
            # rid of those.  Medians of a bunch of columns will then have an
            # odd 'stepped' appearance, which is inevitable because of the 
            # discretization imposed by digital numbers.  I think it is 
            # generally preferable to smooth the bias.
            xpts = np.linspace(0.,len(medianvec),len(medianvec))
            splinefit = UnivariateSpline(xpts,medianvec)
            if showgraph : # purely debugging, will halt execution!
               plt.plot(xpts,splinefit(xpts),color='green')
               plt.plot(xpts,medianvec)
               plt.show()
            column_median = splinefit(xpts)[np.newaxis].T    # makes it into a column.

        else :     
            # Just transpose the straight median if not smoothing.
            column_median = medianvec[np.newaxis].T    # makes it into a column.

        # find zeros before subtracting bias
        if zero_saturated : 
            zeros = (trimquad == 0) 
    
        # .... subtract the bias
        trimquad = trimquad - column_median          
       #  print "trimquad.shape",trimquad.shape
    
        # ... and zero the pixels found earlier.
    
        if zero_saturated :
            trimquad[zeros] = 0
    
        if i == 1 or i == 3 :  # these two quadrants have bad cols
           fixcol(trimquad,badcols[i])
    
        # scribble out a separate FITS file for each quadrant, for 
        # use in determining bad pixels
        # Used these to determine 'badcol' arrays.  Worked
        # nicely.  All bad cols are on the right (quadrants 1 and 3)
        # so there is no need to 'count back' from the center of the 
        # readout array to get the column numbers.
    
        # outname = "quad%d.fits" % i
        # hduout = fits.PrimaryHDU(trimquad) 
        # hduout.writeto(outname)
    
    #    print "i: ",i
    #    print "xlotrim[i%2], xhitrim[i%2] ",xlotrim[i%2],xhitrim[i%2]
    
        # paste the trimmed quadrant into the pre-existing array.
    
        # print("types:",type(ylo[i]),type(yhi[i]),type(xlotrim[i%2]),type(xhitrim[i%2]))

        trimarr[ylo[i]:yhi[i],xlotrim[i%2]:xhitrim[i%2]] = trimquad
    
        if mask_saturated :
            maskout[ylo[i]:yhi[i],xlotrim[i%2]:xhitrim[i%2]] = trimmask.astype(int)
            
    
#    print "Through x-talk repair." 
    if integer_output : 
        trimarr = trimarr.astype('float32')  # halves the storage space

   # At the very end of the process, cut off the first and last columns, 
   # which are often bad.

    trimshape = trimarr.shape
    # cut off the high-x and low-x columns
    trimarr = trimarr[0:trimshape[0],1:trimshape[1]-1]

    # And finally, create and write the output.
    
    hduout = fits.PrimaryHDU(trimarr)
    
    # Katie Weil figured out how to copy the non-geometry parts of the 
    # input header to the output header. 
    
    hdrcopy=hdrin.copy(strip=True)  
    hduout.header.extend(hdrcopy,strip=True,update=True,
        update_first=False,useblanks=True,bottom=False)
    
    hduout.writeto(outfile)
    
    if mask_saturated  :

        outroot = outfile.replace(".fits","")
        maskoutname = outroot + "_mask.fits"

        # trim first and last columns

        maskshape = maskout.shape  # should be same as trimshape
        maskout = maskout[0:maskshape[0],1:maskshaped[1]-1]
    
        hduout = fits.PrimaryHDU(maskout)
        
        hdrcopy=hdrin.copy(strip=True)  
        hduout.header.extend(hdrcopy,strip=True,update=True,
            update_first=False,useblanks=True,bottom=False)
        
        hduout.writeto(maskoutname)
        
    hduin.close()
    

def osbias(imnum, datapath, prefix, corrsat, zerosat, masksat, 
   slitns, getwcs, marktarg, fromlist, targetra, targetdec, 
   targlist, targname) :
   """Bias-subtract an OSMOS image.  It's assumed that it's named
   according to the usual convention  -- e.g. mypath/prefixnumber.fits,
   where 'prefix' usually includes the dot.  This is a thin shell
   around biasquads, designed to be callable as a pyraf task. """
    
   imroot = datapath + prefix + "%04d" % (imnum)
   infilename = imroot + ".fits"
    
   outimroot = "x%04d" % imnum
   outfilename = outimroot + ".fits" 

   biasquads(infilename, outfilename, attempt_saturated_corr = corrsat,
       zero_saturated = zerosat, mask_saturated = masksat) 

parfile = iraf.osfn("/home/thorsten/iraf/uparm/osbias.par")
t = iraf.IrafTaskFactory(taskname = "osbias", value = parfile,
   function = osbias)

if __name__=="__main__" :
   biasquads("/home/thorsten/iraf/jun19/osmosraw/190627/b.0121.fits", "scratchout.fits", attempt_saturated_corr = True, showgraph = True)
