#!/usr/bin/env python
"""osapextract.py -- a little utility for doing the
   aperture finding, tracing, and extraction.  It
   uses object lists written earlier, 
   "obj_[setup string]".  

   Also reads osmosspecred.config to get appropriate
   dispersion line.
"""

import sys
from pyraf import iraf
from iraf import noao, imred, specred, apedit, aptrace, apsum, apfind
from iraf import apresize, apdefault, imstatistics, imdelete, imarith
import os

def get_config() :
    try :
        inf = open("osmosspecred.config","r")
    except :
        print("You need a file called 'osmosspecred.config'.")
        print("For this step, it at least needs the DISPLINE keyword")
        print("in order to get the list of setup strings.")
        print( ".... exiting.")
        sys.exit()

    setups_to_omit = []
    displine = {}   # dispersion line for finding spec (usually the col
                     # containing H-alpha, keyed to spectral setup.
    wavecal = {}    # name of wavecal spectrum, keyed to setup.  These must
                    # already have had ident run and have excellent solutions.
    for l in inf :
        if l[0] != '#' :
            x = l.split('|')
            if x[0].upper().find('PREFIX') > -1 :
                if x[1].find("#") :
                    y = x[1].split('#')
                    prefix = y[0].strip()
                else :
                    prefix = x[1].strip()
            if x[0].upper().find('RAWPARENT') > -1 :
                if x[1].find('#') :
                    y = x[1].split('#')
                    rawdir = y[0].strip()
                else :
                    rawdir = x[1].strip()
            if x[0].upper().find('OMITSETUP') > -1 :
                if x[1].find('#') :
                    y = x[1].split('#')
                    setups_to_omit.append(y[0].strip())
                else :
                    setups_to_omit.append(x[1].strip())

            if x[0].upper().find('DISPLINE') > -1 :
                displine[x[1].strip()] = int(x[2])

            if x[0].upper().find('WAVECAL') > -1 :
                wavecal[x[1].strip()] = x[2]

    return (prefix, rawdir, setups_to_omit, displine, wavecal)

prefix, rawdir, setups_to_omit, displine, wavecal = get_config()

# set a whole bunch of hidden parameters, stolen from 
# modspec + echelle code and modified.

specred.dispaxis = 1  # osmos!

apdefault.lower = -15.0
apdefault.upper = 15.0
apdefault.b_function = "legendre"
apdefault.b_order = 3
apdefault.b_sample = "-200:-40,40:200"
apdefault.b_naverage = 1
apdefault.b_niterate = 2
apdefault.b_low_reject = 3.0
apdefault.b_high_reject = 3.0
apdefault.b_grow = 1.0

apfind.interactive = "no"
apfind.find = "yes"
apfind.recenter = "yes"
apfind.resize = "yes"
apfind.edit = "yes"
apfind.nsum = -20
apfind.nfind = 1

apresize.nsum = -30
apresize.llimit = "INDEF"
apresize.ulimit = "INDEF"
apresize.ylevel = 0.3
apresize.peak = "yes"
apresize.bkg = "yes"
apresize.r_grow = 1.5

apedit.nsum = -40
aptrace.interactive = "yes"
aptrace.find = "no"
aptrace.recenter = "no"
aptrace.resize = "no"
aptrace.edit = "no"
aptrace.trace = "yes"
aptrace.fittrace = "yes"

aptrace.nsum = -60
aptrace.step = 60
aptrace.nlost = 5
# had to re-set to leg for many in 2019 Jan - change default
# from spline 3 order to to legendre order '3', which is a 
# parabola in real life.
aptrace.function = "legendre"
aptrace.order = 3
aptrace.naverage = 1
aptrace.niterate = 1
aptrace.low_reject=3.
# also reject more points automatically.
aptrace.high_reject = 2.5
aptrace.grow = 0

# The displine keys are the different setups, since the 
# dispersion line to trace (generally where H-alpha shows up
# in the spectrum) is determined by the slit, grating, disperser, 
# and so on. 

setups_to_do = displine.keys()

print "setups_to_do: ",setups_to_do

for s in setups_to_omit : 
    setups_to_do.remove(s)

print "setups_to_do: ",setups_to_do

for k in setups_to_do :

    print "*** Set apertures for %s: ***" % (k) 

    apfind.line = displine[k]  # generally H-alpha with this setup
    apresize.line = displine[k]
    aptrace.line = displine[k]
    apedit.line = displine[k]
  
    objlistname = "obj_%s" % (k)

    apedit("@" + objlistname, references = "@" + objlistname, interactive="yes",
        find = "yes",recenter = "yes", resize = "yes",edit = "yes")
    aptrace("@" + objlistname, references = "@" + objlistname,
        interactive="yes",find="no",recenter="no",
        resize="no",edit="no",trace="yes",fittrace="yes",function="spline3",
        order = 2, niterate=1,low_reject=3.0,high_reject=3.0,grow=0)
    
    done = False 

    print """Maybe you screwed up on some of the apedit and aptraces ...
    if so, this is your chance to do 'em over."""
    
    redolist = []
    while not done :
       print "Give numbers to redo (space separated), negative # to exit:"
       stuff = raw_input()
       x = stuff.split()
       for xx in x :
          try :
             num = int(xx)
             if num < 0 :
                done = True 
             else :
                redolist = redolist + [num]
          except :
             pass
    
    for r in redolist :
        im = prefix + "%04d" % r
    
        apedit(im, references = im, interactive="yes",
            find = "yes",recenter = "yes", resize = "yes",edit = "yes")
        aptrace(im, references = im, interactive="yes",find="no",recenter="no",
            resize="no",edit="no",trace="yes",fittrace="yes",function="spline3",
            order = 2, niterate=1,low_reject=3.0,high_reject=3.0,grow=0)
    
    imstatistics.fields  = "mean,stddev" # for checking extractions

    # Do extractions one at a time with thor C program.
    # OR do it with my new opextract.
    # Have to read argument list for real.

    try : 
        inf = open(objlistname,"r") 
        ok = True
    except :
        ok = False

    # replace C-program thorapsum with opextract.py.  This is slower,
    # but a bit more carefully tested and does not occasionally fail and
    # give an output of all-zeros as thorapsum does.

    if ok : 
        for l in inf : 
            
            imname = l.strip()
            os.system("opextract.py --axisdisp 1 --production %s" % (imname))
    
    # Commented-out block uses thorapsum.osmos in case it's necessary to 
    # revert.

#     if ok: 
# 
# 
#         n_redos = 0
#         
#         for l in inf :
#             imname = l.strip()
# 
# 
#             os.system("thorapsum.osmos %s" % imname)
#     
#             # check to be sure it didn't bomb, or flatline -- which is
#             # what happens when thor program fails.  If it did, re-extract
#             # with IRAF apsum.
#           
#             mean = 0.  # initialze
#             stddev = 0.
#             redo = False
#             try : 
#                 stat = imstatistics(imname + ".ms[*,1,1]", Stdout = 1)
#                 fields = stat[1].split()
#                 mean = float(fields[0])
#                 stddev = float(fields[1])
#             except :   # if it throws an exception, it didn't extract at all!
#                 redo = True
#       
#             if (mean == 0. and stddev == 0.) or redo :  # flatline or nonexist.
#                 
#                 n_redos = n_redos + 1
#                 
#                 os.system("rm %s.ms.fits" % imname)  # clobber the bad one
#                 
#                 apsum(imname,output=imname,format="multispec",references=imname,
#                           profiles=imname, apertures=1,
#                           interac="no",find="no",recenter="no",resize="no",
#                           edit="no",trace="no",fittrace="no",extract="yes",
#                           extras="yes",review="no",backgr="fit",
#                           weights="variance",clean="yes",saturation="60000",
#                           readnoise="8.",gain="3.",lsigma="4.",usigma="4.")
#                 print("NOTE: %s scratched and IRAF apsum'd" % (imname))
#     
#         print("Finished extracting 1-d object spectra for %s." % k)
#         print("There were",n_redos," spectra re-done with iraf apextract.")
# 
        # Now go back and extract adjacent comps for this setup.

        comps_exist = False
        try : 
            comp_info = open("adjacent_comps_%s" % (k), "r")
            comps_exist = True
        except : 
            pass

        # associate each comparison spec with a nearby object spec; the only
        # reason to do this is to extract the spectrum from the same rows where the 
        # object is.  If the centering has been consistent, this is probably not needed;
        # in any case, there's no attempt here to fine-tune this.  As soon as a comp
        # spec has been matched to ANY object spec it gives up trying to find a more
        # perfect match, because the precise aperture used for extracting the comps
        # should have very little effect.

        if comps_exist : 
            comp_obj_dict = {}  # dictionary KEY is comp; VALUE is an of the possibly several
                                # object spectra that used the comp.  
            for l in comp_info : 
                x = l.split()
                # object comp1 [comp2] where comp2 is not always there: 
                objspec = x[0]
                for cspec in x[1:] :  # slice for everything else on the line
                    if comp_obj_dict.has_key(cspec) : 
                         pass
                    else : 
                       comp_obj_dict[cspec] = objspec

            ncomps_extracted = 0

            for c in comp_obj_dict.keys() :
                objspec = comp_obj_dict[c]
                # these will all be onedspec, e.g. "ki0123.0001.fits"
                # note that there will be no 'extras' and (critical) the background
                # to subtract is 'none'
                apsum(c,output=c,format="onedspec",references=objspec,
                              profiles=objspec, apertures=1,
                              interac="no",find="no",recenter="no",resize="no",
                              edit="no",trace="no",fittrace="no",extract="yes",
                              extras="no",review="no",backgr="none",
                              weights="none",clean="no",saturation="60000",
                              readnoise="8.",gain="3.",lsigma="4.",usigma="4.")
                ncomps_extracted = ncomps_extracted + 1

            print "%d adjacent comparison spectra were extracted." % (ncomps_extracted)

        else : 
            print "This setup %s had no adjacent comp spectra to extract." % (k)
               
       
print("Finished with extractions.  Next:")
print("  - make and/or copy fitted lamp spec into this directory")
print("  - be sure the corresponding 'idxxx' file is in the 'database' dir")
print("  - edit  osmosspecred.config to point to these and set dispersion params")
print("  - run ossetwavelength.py")

